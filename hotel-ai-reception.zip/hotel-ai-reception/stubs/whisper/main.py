# path: stubs/whisper/main.py
import random
from typing import Optional

from fastapi import FastAPI, File, Form, UploadFile
from pydantic import BaseModel

app = FastAPI(title="Whisper Stub Service")


class TranscriptionResponse(BaseModel):
    text: str
    language: str
    confidence: float
    duration_seconds: float


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "whisper-stub"}


@app.post("/infer", response_model=TranscriptionResponse)
async def transcribe_audio(
    audio: UploadFile = File(...),
    language: Optional[str] = Form(None),
):
    """Transcribe audio to text (stub implementation)."""
    # Mock responses for testing
    mock_texts = {
        "ru": [
            "Я хочу забронировать номер на завтра",
            "Какие номера доступны на следующей неделе?",
            "Мне нужно отменить бронирование",
            "Сколько стоит номер люкс?",
            "Можно оплатить картой?",
        ],
        "en": [
            "I'd like to book a room for tomorrow",
            "What rooms are available next week?",
            "I need to cancel my booking",
            "How much is the suite?",
            "Can I pay by card?",
        ],
    }
    
    # Detect or use provided language
    detected_language = language or random.choice(["ru", "en"])
    
    # Get random text for the language
    texts = mock_texts.get(detected_language, mock_texts["en"])
    text = random.choice(texts)
    
    # Mock processing time
    import asyncio
    await asyncio.sleep(random.uniform(0.5, 2.0))
    
    return TranscriptionResponse(
        text=text,
        language=detected_language,
        confidence=random.uniform(0.85, 0.99),
        duration_seconds=random.uniform(1.0, 5.0),
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)