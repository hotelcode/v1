# path: stubs/coqui/main.py
import random
from typing import Optional

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Coqui TTS Stub Service")


class SynthesizeRequest(BaseModel):
    text: str
    language: str = "ru"
    voice: Optional[str] = None
    speed: float = 1.0


class SynthesizeResponse(BaseModel):
    audio_url: str
    duration_seconds: float
    format: str = "wav"


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "coqui-stub"}


@app.post("/synthesize", response_model=SynthesizeResponse)
async def synthesize_speech(request: SynthesizeRequest):
    """Synthesize speech from text (stub implementation)."""
    # Mock processing time
    import asyncio
    await asyncio.sleep(random.uniform(0.5, 2.0))
    
    # Calculate mock duration based on text length
    words = len(request.text.split())
    duration = words * 0.4 / request.speed  # Roughly 0.4 seconds per word
    
    # Generate mock audio URL
    audio_id = random.randint(100000, 999999)
    audio_url = f"http://coqui-stub:8001/audio/{audio_id}.wav"
    
    return SynthesizeResponse(
        audio_url=audio_url,
        duration_seconds=duration,
        format="wav",
    )


@app.get("/audio/{audio_id}")
async def get_audio(audio_id: str):
    """Get audio file (stub - returns empty response)."""
    # In real implementation, this would return actual audio data
    return {"message": "This is a stub audio endpoint", "audio_id": audio_id}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)