# path: tools/sla_check.py
#!/usr/bin/env python3
"""SLA performance check tool for Hotel AI Reception."""

import asyncio
import csv
import json
import statistics
import time
from datetime import datetime
from typing import Dict, List, Tuple

import httpx
import websockets


class SLAChecker:
    """SLA performance checker."""
    
    def __init__(self, base_url: str = "http://localhost", ws_url: str = "ws://localhost"):
        self.base_url = base_url
        self.ws_url = ws_url
        self.results: List[Dict] = []
    
    async def check_health_endpoint(self) -> Tuple[bool, float]:
        """Check /healthz endpoint performance."""
        async with httpx.AsyncClient() as client:
            start = time.time()
            response = await client.get(f"{self.base_url}/healthz")
            latency = (time.time() - start) * 1000  # ms
            
            success = (
                response.status_code == 200 and
                "X-Trace-ID" in response.headers and
                response.headers.get("Content-Type", "").startswith("application/json")
            )
            
            return success, latency
    
    async def check_websocket_latency(self, num_messages: int = 20) -> List[float]:
        """Check WebSocket chat latency."""
        latencies = []
        
        # Mock authentication token
        token = "mock-test-token"
        
        try:
            async with websockets.connect(f"{self.ws_url}/chat?token={token}") as websocket:
                # Skip welcome message
                await websocket.recv()
                
                for i in range(num_messages):
                    # Send ping message
                    message = json.dumps({
                        "type": "text",
                        "content": f"Test message {i}",
                        "language": "en"
                    })
                    
                    start = time.time()
                    await websocket.send(message)
                    await websocket.recv()  # Wait for response
                    latency = (time.time() - start) * 1000  # ms
                    
                    latencies.append(latency)
                    
                    # Small delay between messages
                    await asyncio.sleep(0.1)
        
        except Exception as e:
            print(f"WebSocket error: {e}")
            return []
        
        return latencies
    
    async def run_scenario_a(self) -> Dict:
        """Scenario A: 1 WebSocket connection × 20 messages."""
        print("Running Scenario A: 1 connection × 20 messages...")
        
        start_time = datetime.now()
        latencies = await self.check_websocket_latency(20)
        
        if not latencies:
            return {
                "scenario": "A",
                "status": "failed",
                "error": "WebSocket connection failed"
            }
        
        result = {
            "scenario": "A",
            "status": "passed",
            "start_time": start_time.isoformat(),
            "message_count": len(latencies),
            "min_latency_ms": min(latencies),
            "max_latency_ms": max(latencies),
            "avg_latency_ms": statistics.mean(latencies),
            "p50_latency_ms": statistics.median(latencies),
            "p95_latency_ms": statistics.quantiles(latencies, n=20)[18],  # 95th percentile
            "p99_latency_ms": statistics.quantiles(latencies, n=100)[98] if len(latencies) >= 100 else max(latencies),
        }
        
        # Check SLA
        if result["p95_latency_ms"] > 400:
            result["status"] = "failed"
            result["reason"] = f"P95 latency {result['p95_latency_ms']:.2f}ms exceeds 400ms SLA"
        
        return result
    
    async def run_scenario_b(self) -> Dict:
        """Scenario B: 20 WebSocket connections × 5 messages each."""
        print("Running Scenario B: 20 connections × 5 messages each...")
        
        start_time = datetime.now()
        all_latencies = []
        
        async def client_task(client_id: int) -> List[float]:
            """Run a single client connection."""
            return await self.check_websocket_latency(5)
        
        # Run 20 concurrent connections
        tasks = [client_task(i) for i in range(20)]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Collect all latencies
        for result in results:
            if isinstance(result, list):
                all_latencies.extend(result)
        
        if not all_latencies:
            return {
                "scenario": "B",
                "status": "failed",
                "error": "All WebSocket connections failed"
            }
        
        result = {
            "scenario": "B",
            "status": "passed",
            "start_time": start_time.isoformat(),
            "connection_count": 20,
            "messages_per_connection": 5,
            "total_messages": len(all_latencies),
            "min_latency_ms": min(all_latencies),
            "max_latency_ms": max(all_latencies),
            "avg_latency_ms": statistics.mean(all_latencies),
            "p50_latency_ms": statistics.median(all_latencies),
            "p95_latency_ms": statistics.quantiles(all_latencies, n=20)[18],
            "p99_latency_ms": statistics.quantiles(all_latencies, n=100)[98] if len(all_latencies) >= 100 else max(all_latencies),
        }
        
        # Check SLA
        if result["p95_latency_ms"] > 800:
            result["status"] = "failed"
            result["reason"] = f"P95 latency {result['p95_latency_ms']:.2f}ms exceeds 800ms SLA"
        
        return result
    
    async def run_health_check(self) -> Dict:
        """Run health check endpoint test."""
        print("Running health check test...")
        
        success, latency = await self.check_health_endpoint()
        
        return {
            "test": "health_check",
            "status": "passed" if success else "failed",
            "latency_ms": latency,
            "timestamp": datetime.now().isoformat(),
        }
    
    def save_results(self, filename: str = "report.csv"):
        """Save results to CSV file."""
        if not self.results:
            print("No results to save")
            return
        
        # Flatten results for CSV
        rows = []
        for result in self.results:
            if "scenario" in result:
                # WebSocket scenario results
                rows.append({
                    "test_type": f"websocket_scenario_{result['scenario']}",
                    "status": result["status"],
                    "timestamp": result.get("start_time", ""),
                    "p95_latency_ms": result.get("p95_latency_ms", ""),
                    "avg_latency_ms": result.get("avg_latency_ms", ""),
                    "message_count": result.get("total_messages", result.get("message_count", "")),
                    "error": result.get("error", result.get("reason", "")),
                })
            else:
                # Health check result
                rows.append({
                    "test_type": result["test"],
                    "status": result["status"],
                    "timestamp": result["timestamp"],
                    "p95_latency_ms": result["latency_ms"],
                    "avg_latency_ms": result["latency_ms"],
                    "message_count": 1,
                    "error": "" if result["status"] == "passed" else "Health check failed",
                })
        
        # Write CSV
        with open(filename, "w", newline="") as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
        
        print(f"Results saved to {filename}")
    
    def print_summary(self):
        """Print summary of results."""
        print("\n" + "="*60)
        print("SLA CHECK SUMMARY")
        print("="*60)
        
        for result in self.results:
            if "scenario" in result:
                print(f"\nScenario {result['scenario']}:")
                print(f"  Status: {result['status'].upper()}")
                if result["status"] == "passed":
                    print(f"  P95 Latency: {result.get('p95_latency_ms', 'N/A'):.2f} ms")
                    print(f"  Avg Latency: {result.get('avg_latency_ms', 'N/A'):.2f} ms")
                    print(f"  Messages: {result.get('total_messages', result.get('message_count', 'N/A'))}")
                else:
                    print(f"  Error: {result.get('error', result.get('reason', 'Unknown'))}")
            else:
                print(f"\n{result['test']}:")
                print(f"  Status: {result['status'].upper()}")
                print(f"  Latency: {result['latency_ms']:.2f} ms")
        
        print("\n" + "="*60)
        
        # Overall status
        all_passed = all(r["status"] == "passed" for r in self.results)
        print(f"OVERALL: {'PASSED' if all_passed else 'FAILED'}")
        print("="*60)
    
    async def run_all_checks(self):
        """Run all SLA checks."""
        # Health check
        health_result = await self.run_health_check()
        self.results.append(health_result)
        
        # Only run WebSocket tests if health check passes
        if health_result["status"] == "passed":
            # Scenario A
            scenario_a = await self.run_scenario_a()
            self.results.append(scenario_a)
            
            # Small delay between scenarios
            await asyncio.sleep(1)
            
            # Scenario B
            scenario_b = await self.run_scenario_b()
            self.results.append(scenario_b)
        else:
            print("Skipping WebSocket tests due to failed health check")
        
        # Print summary
        self.print_summary()
        
        # Save results
        self.save_results()
        
        # Return exit code
        return 0 if all(r["status"] == "passed" for r in self.results) else 1


async def main():
    """Main entry point."""
    import sys
    
    # Parse arguments
    base_url = sys.argv[1] if len(sys.argv) > 1 else "http://localhost"
    ws_url = base_url.replace("http://", "ws://").replace("https://", "wss://")
    
    print(f"Running SLA checks against {base_url}")
    
    # Run checks
    checker = SLAChecker(base_url, ws_url)
    exit_code = await checker.run_all_checks()
    
    sys.exit(exit_code)


if __name__ == "__main__":
    asyncio.run(main())