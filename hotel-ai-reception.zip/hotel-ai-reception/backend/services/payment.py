# path: backend/services/payment.py
import random
import string
from datetime import datetime
from decimal import Decimal
from typing import List, Optional, Tuple

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload

from backend.core.exceptions import (
    ConflictException,
    NotFoundException,
    PaymentFailedException,
    RefundNotAllowedException,
    ValidationException,
)
from backend.models import Booking, BookingStatus, Payment, PaymentMethod, PaymentStatus
from backend.schemas.payment import PaymentCreate


class PaymentService:
    """Service for managing payments."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_payment(
        self,
        payment_data: PaymentCreate,
        created_by_id: int,
    ) -> Payment:
        """Create a new payment."""
        # Get booking
        booking = await self.db.get(Booking, payment_data.booking_id)
        if not booking:
            raise NotFoundException(f"Booking {payment_data.booking_id} not found")
        
        # Validate booking status
        if booking.status not in [BookingStatus.PENDING, BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]:
            raise ValidationException(f"Cannot create payment for booking with status {booking.status.value}")
        
        # Validate amount
        if payment_data.amount <= 0:
            raise ValidationException("Payment amount must be greater than 0")
        
        # Check if payment would exceed total amount
        if booking.paid_amount + payment_data.amount > booking.total_amount:
            raise ValidationException(
                f"Payment amount ({payment_data.amount}) would exceed remaining balance ({booking.balance_due})"
            )
        
        # Generate payment reference
        payment_ref = await self._generate_payment_ref()
        
        # Create payment
        payment = Payment(
            payment_ref=payment_ref,
            booking_id=payment_data.booking_id,
            amount=payment_data.amount,
            currency=payment_data.currency,
            payment_method=payment_data.payment_method,
            status=PaymentStatus.PENDING,
            card_last_four=payment_data.card_last_four,
            card_brand=payment_data.card_brand,
            notes=payment_data.notes,
        )
        
        self.db.add(payment)
        await self.db.commit()
        await self.db.refresh(payment)
        
        # Process payment immediately for cash
        if payment.payment_method == PaymentMethod.CASH:
            payment = await self.process_payment(payment.id)
        
        return payment
    
    async def get_payment(self, payment_id: int) -> Optional[Payment]:
        """Get payment by ID."""
        stmt = (
            select(Payment)
            .options(joinedload(Payment.booking).joinedload(Booking.guest))
            .where(Payment.id == payment_id)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    async def list_payments(
        self,
        offset: int = 0,
        limit: int = 20,
        booking_id: Optional[int] = None,
        guest_id: Optional[int] = None,
        status: Optional[str] = None,
        payment_method: Optional[str] = None,
    ) -> Tuple[List[Payment], int]:
        """List payments with filters."""
        query = select(Payment).options(
            joinedload(Payment.booking).joinedload(Booking.guest)
        )
        count_query = select(func.count(Payment.id))
        
        # Join with booking for guest filter
        if guest_id:
            query = query.join(Booking).where(Booking.guest_id == guest_id)
            count_query = count_query.join(Booking).where(Booking.guest_id == guest_id)
        
        # Apply filters
        if booking_id:
            query = query.where(Payment.booking_id == booking_id)
            count_query = count_query.where(Payment.booking_id == booking_id)
        
        if status:
            try:
                status_enum = PaymentStatus(status)
                query = query.where(Payment.status == status_enum)
                count_query = count_query.where(Payment.status == status_enum)
            except ValueError:
                pass
        
        if payment_method:
            try:
                method_enum = PaymentMethod(payment_method)
                query = query.where(Payment.payment_method == method_enum)
                count_query = count_query.where(Payment.payment_method == method_enum)
            except ValueError:
                pass
        
        # Get total count
        total = await self.db.scalar(count_query)
        
        # Apply pagination and ordering
        query = query.order_by(Payment.created_at.desc()).offset(offset).limit(limit)
        
        # Execute query
        result = await self.db.execute(query)
        payments = result.unique().scalars().all()
        
        return payments, total
    
    async def get_booking_payments(self, booking_id: int) -> List[Payment]:
        """Get all payments for a booking."""
        stmt = (
            select(Payment)
            .where(Payment.booking_id == booking_id)
            .order_by(Payment.created_at.desc())
        )
        result = await self.db.execute(stmt)
        return result.scalars().all()
    
    async def process_payment(self, payment_id: int) -> Payment:
        """Process a pending payment."""
        payment = await self.get_payment(payment_id)
        if not payment:
            raise NotFoundException(f"Payment {payment_id} not found")
        
        if payment.status != PaymentStatus.PENDING:
            raise ConflictException(f"Payment {payment_id} is not pending")
        
        # Update payment status to processing
        payment.status = PaymentStatus.PROCESSING
        await self.db.commit()
        
        try:
            # Process payment based on method
            if payment.payment_method == PaymentMethod.CASH:
                # Cash payments are immediately successful
                success = True
                transaction_id = f"CASH-{payment.payment_ref}"
            elif payment.payment_method == PaymentMethod.CARD:
                # TODO: Integrate with payment gateway
                success = True  # Mock success
                transaction_id = f"CARD-{random.randint(100000, 999999)}"
            elif payment.payment_method == PaymentMethod.BANK_TRANSFER:
                # TODO: Check bank transfer status
                success = True  # Mock success
                transaction_id = f"BANK-{random.randint(100000, 999999)}"
            elif payment.payment_method == PaymentMethod.ONLINE:
                # TODO: Process online payment
                success = True  # Mock success
                transaction_id = f"ONLINE-{random.randint(100000, 999999)}"
            else:
                success = False
                transaction_id = None
            
            if success:
                payment.status = PaymentStatus.COMPLETED
                payment.transaction_id = transaction_id
                payment.processed_at = datetime.utcnow()
                payment.gateway_response = {"status": "success", "mock": True}
                
                # Update booking paid amount
                booking = await self.db.get(Booking, payment.booking_id)
                booking.paid_amount += payment.amount
                
                # Update booking status if fully paid
                if booking.is_paid_in_full and booking.status == BookingStatus.PENDING:
                    booking.status = BookingStatus.CONFIRMED
                
            else:
                payment.status = PaymentStatus.FAILED
                payment.failed_at = datetime.utcnow()
                payment.error_code = "MOCK_FAILURE"
                payment.error_message = "Mock payment failure"
                raise PaymentFailedException("Payment processing failed")
            
        except Exception as e:
            payment.status = PaymentStatus.FAILED
            payment.failed_at = datetime.utcnow()
            payment.error_message = str(e)
            await self.db.commit()
            raise
        
        await self.db.commit()
        await self.db.refresh(payment)
        
        # TODO: Send payment confirmation
        
        return payment
    
    async def refund_payment(
        self,
        payment_id: int,
        amount: Decimal,
        reason: str,
        refunded_by_id: int,
    ) -> Payment:
        """Refund a payment."""
        payment = await self.get_payment(payment_id)
        if not payment:
            raise NotFoundException(f"Payment {payment_id} not found")
        
        if not payment.is_refundable:
            raise RefundNotAllowedException(f"Payment {payment_id} cannot be refunded")
        
        # Validate refund amount
        if amount <= 0:
            raise ValidationException("Refund amount must be greater than 0")
        
        if amount > payment.net_amount:
            raise ValidationException(f"Refund amount ({amount}) exceeds payment amount ({payment.net_amount})")
        
        # Process refund based on payment method
        if payment.payment_method == PaymentMethod.CASH:
            # Cash refunds require manual processing
            refund_success = True
        else:
            # TODO: Process refund through payment gateway
            refund_success = True  # Mock success
        
        if refund_success:
            if amount == payment.net_amount:
                payment.status = PaymentStatus.REFUNDED
            else:
                payment.status = PaymentStatus.PARTIALLY_REFUNDED
            
            payment.refund_amount = (payment.refund_amount or Decimal("0")) + amount
            payment.refund_reason = reason
            payment.refunded_at = datetime.utcnow()
            
            # Update booking paid amount
            booking = await self.db.get(Booking, payment.booking_id)
            booking.paid_amount -= amount
            
            await self.db.commit()
            await self.db.refresh(payment)
            
            # TODO: Send refund confirmation
            
            return payment
        else:
            raise PaymentFailedException("Refund processing failed")
    
    async def _generate_payment_ref(self) -> str:
        """Generate unique payment reference."""
        while True:
            ref = "PAY-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=10))
            
            # Check if exists
            stmt = select(Payment).where(Payment.payment_ref == ref)
            result = await self.db.execute(stmt)
            if not result.scalar_one_or_none():
                return ref