# path: backend/services/booking.py
import random
import string
from datetime import datetime
from decimal import Decimal
from typing import List, Optional, Tuple

from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload

from backend.config import BOOKING_STATUS, calculate_prepayment_amount, calculate_refund_amount
from backend.core.exceptions import (
    BookingNotFoundException,
    ConflictException,
    InvalidBookingDatesException,
    RoomNotAvailableException,
    ValidationException,
)
from backend.models import Booking, BookingStatus, Room, RoomStatus
from backend.schemas.booking import BookingCreate, BookingUpdate


class BookingService:
    """Service for managing bookings."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_booking(
        self,
        booking_data: BookingCreate,
        created_by_id: int,
    ) -> Booking:
        """Create a new booking."""
        # Validate dates
        if booking_data.check_out_date <= booking_data.check_in_date:
            raise InvalidBookingDatesException("Check-out date must be after check-in date")
        
        # Check room availability
        room = await self.db.get(Room, booking_data.room_id)
        if not room:
            raise ValidationException(f"Room {booking_data.room_id} not found")
        
        if not room.is_available:
            raise RoomNotAvailableException(str(booking_data.room_id))
        
        # Check if room is available for the dates
        is_available = await self._check_room_availability(
            room_id=booking_data.room_id,
            check_in=booking_data.check_in_date,
            check_out=booking_data.check_out_date,
        )
        
        if not is_available:
            raise RoomNotAvailableException(str(booking_data.room_id))
        
        # Validate occupancy
        total_guests = booking_data.num_adults + booking_data.num_children
        if total_guests > room.max_occupancy:
            raise ValidationException(
                f"Total guests ({total_guests}) exceeds room capacity ({room.max_occupancy})"
            )
        
        # Calculate pricing
        nights = (booking_data.check_out_date - booking_data.check_in_date).days
        room_rate = booking_data.room_rate or room.base_price
        total_amount = room_rate * nights
        
        # Generate booking reference
        booking_ref = await self._generate_booking_ref()
        
        # Create booking
        booking = Booking(
            booking_ref=booking_ref,
            guest_id=booking_data.guest_id,
            room_id=booking_data.room_id,
            check_in_date=booking_data.check_in_date,
            check_out_date=booking_data.check_out_date,
            num_adults=booking_data.num_adults,
            num_children=booking_data.num_children,
            room_rate=room_rate,
            total_amount=total_amount,
            special_requests=booking_data.special_requests,
            guest_preferences=booking_data.guest_preferences,
            guest_email=booking_data.guest_email,
            guest_phone=booking_data.guest_phone,
            booking_source=booking_data.booking_source,
            internal_notes=booking_data.internal_notes,
            requires_prepayment=booking_data.requires_prepayment,
            is_guaranteed=booking_data.is_guaranteed,
            status=BookingStatus.PENDING,
        )
        
        self.db.add(booking)
        await self.db.commit()
        await self.db.refresh(booking)
        
        # Load relations
        await self.db.refresh(booking, ["room", "guest"])
        
        # TODO: Send confirmation notification
        
        return booking
    
    async def get_booking(self, booking_id: int) -> Optional[Booking]:
        """Get booking by ID."""
        stmt = (
            select(Booking)
            .options(joinedload(Booking.room), joinedload(Booking.guest))
            .where(Booking.id == booking_id)
        )
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    async def list_bookings(
        self,
        offset: int = 0,
        limit: int = 20,
        status: Optional[str] = None,
        room_id: Optional[int] = None,
        guest_id: Optional[int] = None,
        check_in_date: Optional[str] = None,
    ) -> Tuple[List[Booking], int]:
        """List bookings with filters."""
        query = select(Booking).options(
            joinedload(Booking.room),
            joinedload(Booking.guest)
        )
        count_query = select(func.count(Booking.id))
        
        # Apply filters
        if status:
            try:
                status_enum = BookingStatus(status)
                query = query.where(Booking.status == status_enum)
                count_query = count_query.where(Booking.status == status_enum)
            except ValueError:
                pass
        
        if room_id:
            query = query.where(Booking.room_id == room_id)
            count_query = count_query.where(Booking.room_id == room_id)
        
        if guest_id:
            query = query.where(Booking.guest_id == guest_id)
            count_query = count_query.where(Booking.guest_id == guest_id)
        
        if check_in_date:
            query = query.where(Booking.check_in_date == check_in_date)
            count_query = count_query.where(Booking.check_in_date == check_in_date)
        
        # Get total count
        total = await self.db.scalar(count_query)
        
        # Apply pagination and ordering
        query = query.order_by(Booking.created_at.desc()).offset(offset).limit(limit)
        
        # Execute query
        result = await self.db.execute(query)
        bookings = result.unique().scalars().all()
        
        return bookings, total
    
    async def update_booking(
        self,
        booking_id: int,
        booking_update: BookingUpdate,
        updated_by_id: int,
    ) -> Booking:
        """Update booking details."""
        booking = await self.get_booking(booking_id)
        if not booking:
            raise BookingNotFoundException(str(booking_id))
        
        # Validate status change
        if booking_update.status and not self._can_transition_status(
            booking.status, booking_update.status
        ):
            raise ValidationException(
                f"Cannot transition from {booking.status.value} to {booking_update.status.value}"
            )
        
        # Update fields
        update_data = booking_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(booking, field, value)
        
        booking.updated_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(booking, ["room", "guest"])
        
        return booking
    
    async def cancel_booking(
        self,
        booking_id: int,
        reason: Optional[str] = None,
        cancelled_by_id: Optional[int] = None,
    ) -> Booking:
        """Cancel a booking."""
        booking = await self.get_booking(booking_id)
        if not booking:
            raise BookingNotFoundException(str(booking_id))
        
        if not booking.can_cancel:
            raise ConflictException(f"Booking {booking_id} cannot be cancelled")
        
        # Calculate refund
        hours_before_checkin = (
            booking.check_in_date - datetime.now().date()
        ).total_seconds() / 3600
        
        refund_amount = calculate_refund_amount(
            booking.paid_amount,
            hours_before_checkin
        )
        
        # Update booking
        booking.status = BookingStatus.CANCELLED
        booking.cancelled_at = datetime.utcnow()
        booking.cancellation_reason = reason
        booking.refund_amount = refund_amount
        
        await self.db.commit()
        await self.db.refresh(booking, ["room", "guest"])
        
        # TODO: Process refund if applicable
        # TODO: Send cancellation notification
        
        return booking
    
    async def check_in(
        self,
        booking_id: int,
        checked_in_by_id: int,
    ) -> Booking:
        """Check in a guest."""
        booking = await self.get_booking(booking_id)
        if not booking:
            raise BookingNotFoundException(str(booking_id))
        
        if not booking.can_check_in:
            raise ConflictException(f"Cannot check in booking {booking_id}")
        
        # Update booking
        booking.status = BookingStatus.CHECKED_IN
        booking.actual_check_in = datetime.utcnow()
        
        # Update room status
        room = await self.db.get(Room, booking.room_id)
        room.status = RoomStatus.OCCUPIED
        
        await self.db.commit()
        await self.db.refresh(booking, ["room", "guest"])
        
        return booking
    
    async def check_out(
        self,
        booking_id: int,
        checked_out_by_id: int,
    ) -> Booking:
        """Check out a guest."""
        booking = await self.get_booking(booking_id)
        if not booking:
            raise BookingNotFoundException(str(booking_id))
        
        if not booking.can_check_out:
            raise ConflictException(f"Cannot check out booking {booking_id}")
        
        # Update booking
        booking.status = BookingStatus.CHECKED_OUT
        booking.actual_check_out = datetime.utcnow()
        
        # Update room status
        room = await self.db.get(Room, booking.room_id)
        room.status = RoomStatus.CLEANING
        
        await self.db.commit()
        await self.db.refresh(booking, ["room", "guest"])
        
        # TODO: Generate final invoice
        # TODO: Send checkout notification
        
        return booking
    
    async def _check_room_availability(
        self,
        room_id: int,
        check_in: datetime,
        check_out: datetime,
        exclude_booking_id: Optional[int] = None,
    ) -> bool:
        """Check if room is available for given dates."""
        query = select(Booking).where(
            and_(
                Booking.room_id == room_id,
                Booking.status.in_([
                    BookingStatus.CONFIRMED,
                    BookingStatus.CHECKED_IN,
                ]),
                or_(
                    and_(
                        Booking.check_in_date < check_out,
                        Booking.check_out_date > check_in,
                    ),
                    and_(
                        Booking.check_in_date >= check_in,
                        Booking.check_in_date < check_out,
                    ),
                ),
            )
        )
        
        if exclude_booking_id:
            query = query.where(Booking.id != exclude_booking_id)
        
        result = await self.db.execute(query)
        conflicting_bookings = result.scalars().all()
        
        return len(conflicting_bookings) == 0
    
    async def _generate_booking_ref(self) -> str:
        """Generate unique booking reference."""
        while True:
            ref = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
            
            # Check if exists
            stmt = select(Booking).where(Booking.booking_ref == ref)
            result = await self.db.execute(stmt)
            if not result.scalar_one_or_none():
                return ref
    
    def _can_transition_status(
        self,
        current: BookingStatus,
        new: BookingStatus,
    ) -> bool:
        """Check if status transition is allowed."""
        allowed_transitions = {
            BookingStatus.PENDING: [
                BookingStatus.CONFIRMED,
                BookingStatus.CANCELLED,
            ],
            BookingStatus.CONFIRMED: [
                BookingStatus.CHECKED_IN,
                BookingStatus.CANCELLED,
                BookingStatus.NO_SHOW,
            ],
            BookingStatus.CHECKED_IN: [
                BookingStatus.CHECKED_OUT,
            ],
            BookingStatus.CHECKED_OUT: [],
            BookingStatus.CANCELLED: [],
            BookingStatus.NO_SHOW: [],
        }
        
        return new in allowed_transitions.get(current, [])