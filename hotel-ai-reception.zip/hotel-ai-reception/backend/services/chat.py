# path: backend/services/chat.py
import base64
import json
from datetime import datetime
from typing import Any, Dict, Optional

import httpx
import redis.asyncio as redis
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import AI_ASSISTANT_CONFIG
from backend.core import get_logger, get_settings
from backend.models import Booking, Room, User
from backend.schemas.chat import ChatContext, ChatIntent

settings = get_settings()
logger = get_logger(__name__)


class ChatService:
    """Service for managing chat and AI interactions."""
    
    def __init__(self, db: AsyncSession, redis_client: redis.Redis):
        self.db = db
        self.redis = redis_client
        self.http_client = httpx.AsyncClient(timeout=30.0)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.http_client.aclose()
    
    async def process_text_message(
        self,
        user_id: int,
        content: str,
        language: str = "ru",
    ) -> str:
        """Process text message and generate response."""
        # Get or create chat context
        context = await self._get_chat_context(user_id)
        
        # Update context from message
        context.update_from_message(content, language)
        
        # Generate response based on intent
        response = await self._generate_response(user_id, content, context, language)
        
        # Save context
        await self._save_chat_context(user_id, context)
        
        # Log chat interaction
        logger.info(
            "chat_message_processed",
            user_id=user_id,
            intent=context.intent.value,
            language=language,
        )
        
        return response
    
    async def transcribe_audio(self, audio_data: str) -> str:
        """Transcribe audio to text using Whisper service."""
        try:
            # Decode base64 audio
            audio_bytes = base64.b64decode(audio_data)
            
            # Send to Whisper service
            response = await self.http_client.post(
                f"{settings.WHISPER_SERVICE_URL}/infer",
                files={"audio": ("audio.wav", audio_bytes, "audio/wav")},
                timeout=60.0,
            )
            response.raise_for_status()
            
            result = response.json()
            return result.get("text", "")
            
        except Exception as e:
            logger.error("audio_transcription_failed", error=str(e))
            raise
    
    async def synthesize_speech(self, text: str, language: str = "ru") -> str:
        """Synthesize speech from text using Coqui TTS."""
        try:
            # Prepare request
            payload = {
                "text": text,
                "language": language,
                "voice": self._get_voice_for_language(language),
            }
            
            # Send to Coqui service
            response = await self.http_client.post(
                f"{settings.COQUI_SERVICE_URL}/synthesize",
                json=payload,
                timeout=60.0,
            )
            response.raise_for_status()
            
            result = response.json()
            return result.get("audio_url", "")
            
        except Exception as e:
            logger.error("speech_synthesis_failed", error=str(e))
            raise
    
    async def _get_chat_context(self, user_id: int) -> ChatContext:
        """Get or create chat context for user."""
        key = f"chat:context:{user_id}"
        
        # Try to get from Redis
        context_data = await self.redis.get(key)
        if context_data:
            try:
                data = json.loads(context_data)
                return ChatContext(**data)
            except Exception:
                pass
        
        # Create new context
        return ChatContext()
    
    async def _save_chat_context(self, user_id: int, context: ChatContext) -> None:
        """Save chat context to Redis."""
        key = f"chat:context:{user_id}"
        context_data = context.model_dump_json()
        
        # Save with 24 hour expiration
        await self.redis.setex(key, 86400, context_data)
    
    async def _generate_response(
        self,
        user_id: int,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Generate response based on intent and context."""
        # Get user info
        user = await self.db.get(User, user_id)
        if not user:
            return self._get_error_response(language)
        
        # Route to appropriate handler based on intent
        if context.intent == ChatIntent.BOOKING_CREATE:
            return await self._handle_booking_create(user, message, context, language)
        elif context.intent == ChatIntent.BOOKING_INFO:
            return await self._handle_booking_info(user, message, context, language)
        elif context.intent == ChatIntent.ROOM_INFO:
            return await self._handle_room_info(user, message, context, language)
        elif context.intent == ChatIntent.ROOM_AVAILABILITY:
            return await self._handle_room_availability(user, message, context, language)
        elif context.intent == ChatIntent.PAYMENT_INFO:
            return await self._handle_payment_info(user, message, context, language)
        elif context.intent == ChatIntent.GENERAL_INFO:
            return await self._handle_general_info(user, message, context, language)
        else:
            return self._get_default_response(language)
    
    async def _handle_booking_create(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle booking creation intent."""
        # TODO: Implement booking creation flow
        if language == "ru":
            return (
                "Я помогу вам забронировать номер. "
                "Пожалуйста, укажите желаемые даты заезда и выезда, "
                "а также количество гостей."
            )
        else:
            return (
                "I'll help you book a room. "
                "Please specify your check-in and check-out dates, "
                "as well as the number of guests."
            )
    
    async def _handle_booking_info(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle booking information request."""
        # Get user's active bookings
        from backend.services.booking import BookingService
        booking_service = BookingService(self.db)
        
        bookings, _ = await booking_service.list_bookings(
            guest_id=user.id,
            status=BookingStatus.CONFIRMED.value,
            limit=5,
        )
        
        if not bookings:
            if language == "ru":
                return "У вас нет активных бронирований."
            else:
                return "You don't have any active bookings."
        
        # Format booking information
        if language == "ru":
            response = "Ваши активные бронирования:\n\n"
            for booking in bookings:
                response += (
                    f"📅 Бронь #{booking.booking_ref}\n"
                    f"🏨 Номер: {booking.room.room_number}\n"
                    f"📆 Заезд: {booking.check_in_date}\n"
                    f"📆 Выезд: {booking.check_out_date}\n"
                    f"💰 К оплате: {booking.balance_due} KZT\n\n"
                )
        else:
            response = "Your active bookings:\n\n"
            for booking in bookings:
                response += (
                    f"📅 Booking #{booking.booking_ref}\n"
                    f"🏨 Room: {booking.room.room_number}\n"
                    f"📆 Check-in: {booking.check_in_date}\n"
                    f"📆 Check-out: {booking.check_out_date}\n"
                    f"💰 Balance due: {booking.balance_due} KZT\n\n"
                )
        
        return response.strip()
    
    async def _handle_room_info(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle room information request."""
        # TODO: Extract room number from message
        if language == "ru":
            return (
                "Пожалуйста, укажите номер комнаты, "
                "о которой вы хотите получить информацию."
            )
        else:
            return (
                "Please specify the room number "
                "you'd like information about."
            )
    
    async def _handle_room_availability(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle room availability check."""
        # TODO: Extract dates from message
        if language == "ru":
            return (
                "Для проверки доступности номеров, "
                "пожалуйста, укажите даты заезда и выезда."
            )
        else:
            return (
                "To check room availability, "
                "please specify your check-in and check-out dates."
            )
    
    async def _handle_payment_info(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle payment information request."""
        if language == "ru":
            return (
                "Вы можете оплатить бронирование следующими способами:\n"
                "💳 Банковская карта\n"
                "💵 Наличные при заселении\n"
                "🏦 Банковский перевод\n\n"
                "Для оплаты конкретного бронирования, "
                "укажите номер брони."
            )
        else:
            return (
                "You can pay for your booking using:\n"
                "💳 Credit/debit card\n"
                "💵 Cash at check-in\n"
                "🏦 Bank transfer\n\n"
                "To pay for a specific booking, "
                "please provide the booking reference."
            )
    
    async def _handle_general_info(
        self,
        user: User,
        message: str,
        context: ChatContext,
        language: str,
    ) -> str:
        """Handle general information request."""
        if language == "ru":
            return (
                "Добро пожаловать в наш отель! 🏨\n\n"
                "Время заезда: 14:00\n"
                "Время выезда: 12:00\n\n"
                "Я могу помочь вам с:\n"
                "• Бронированием номеров\n"
                "• Информацией о номерах\n"
                "• Проверкой доступности\n"
                "• Вопросами об оплате\n\n"
                "Чем могу помочь?"
            )
        else:
            return (
                "Welcome to our hotel! 🏨\n\n"
                "Check-in time: 14:00\n"
                "Check-out time: 12:00\n\n"
                "I can help you with:\n"
                "• Room bookings\n"
                "• Room information\n"
                "• Availability checks\n"
                "• Payment questions\n\n"
                "How can I help you?"
            )
    
    def _get_default_response(self, language: str) -> str:
        """Get default response."""
        if language == "ru":
            return (
                "Я не совсем понял ваш вопрос. "
                "Пожалуйста, уточните, что вас интересует:\n"
                "• Бронирование номера\n"
                "• Информация о бронировании\n"
                "• Доступность номеров\n"
                "• Вопросы об оплате"
            )
        else:
            return (
                "I didn't quite understand your question. "
                "Please clarify what you're interested in:\n"
                "• Room booking\n"
                "• Booking information\n"
                "• Room availability\n"
                "• Payment questions"
            )
    
    def _get_error_response(self, language: str) -> str:
        """Get error response."""
        if language == "ru":
            return "Извините, произошла ошибка. Пожалуйста, попробуйте позже."
        else:
            return "Sorry, an error occurred. Please try again later."
    
    def _get_voice_for_language(self, language: str) -> str:
        """Get voice name for language."""
        voices = {
            "ru": "ru-RU-Standard-A",
            "en": "en-US-Standard-A",
            "kk": "ru-RU-Standard-A",  # Fallback to Russian
        }
        return voices.get(language, "en-US-Standard-A")