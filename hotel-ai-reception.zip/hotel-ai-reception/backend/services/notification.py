# path: backend/services/notification.py
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Dict, List, Optional

from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import NOTIFICATION_CONFIG
from backend.core import get_logger, get_settings
from backend.models import Booking, User
from backend.telegram.bot import telegram_bot

settings = get_settings()
logger = get_logger(__name__)


class NotificationService:
    """Service for sending notifications."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def send_booking_confirmation(self, booking: Booking) -> None:
        """Send booking confirmation to guest."""
        config = NOTIFICATION_CONFIG["booking_confirmation"]
        
        # Get guest details
        guest = await self.db.get(User, booking.guest_id)
        if not guest:
            return
        
        # Prepare message content
        message = self._format_booking_confirmation(booking, guest.language)
        
        # Send via configured channels
        if config["email"] and guest.email:
            await self._send_email(
                to_email=guest.email,
                subject=self._get_subject("booking_confirmation", guest.language),
                body=message,
            )
        
        if config["telegram"] and guest.telegram_id:
            await self._send_telegram(
                chat_id=guest.telegram_id,
                text=message,
            )
        
        if config["sms"] and guest.phone and settings.ENABLE_SMS_NOTIFICATIONS:
            await self._send_sms(
                phone=guest.phone,
                text=message,
            )
        
        logger.info(
            "booking_confirmation_sent",
            booking_id=booking.id,
            guest_id=guest.id,
        )
    
    async def send_check_in_reminder(self, booking: Booking) -> None:
        """Send check-in reminder to guest."""
        config = NOTIFICATION_CONFIG["check_in_reminder"]
        
        # Get guest details
        guest = await self.db.get(User, booking.guest_id)
        if not guest:
            return
        
        # Prepare message content
        message = self._format_check_in_reminder(booking, guest.language)
        
        # Send via configured channels
        if config["email"] and guest.email:
            await self._send_email(
                to_email=guest.email,
                subject=self._get_subject("check_in_reminder", guest.language),
                body=message,
            )
        
        if config["telegram"] and guest.telegram_id:
            await self._send_telegram(
                chat_id=guest.telegram_id,
                text=message,
            )
        
        logger.info(
            "check_in_reminder_sent",
            booking_id=booking.id,
            guest_id=guest.id,
        )
    
    async def send_check_out_reminder(self, booking: Booking) -> None:
        """Send check-out reminder to guest."""
        config = NOTIFICATION_CONFIG["check_out_reminder"]
        
        # Get guest details
        guest = await self.db.get(User, booking.guest_id)
        if not guest:
            return
        
        # Prepare message content
        message = self._format_check_out_reminder(booking, guest.language)
        
        # Send via telegram (primary channel for urgent reminders)
        if config["telegram"] and guest.telegram_id:
            await self._send_telegram(
                chat_id=guest.telegram_id,
                text=message,
            )
        
        logger.info(
            "check_out_reminder_sent",
            booking_id=booking.id,
            guest_id=guest.id,
        )
    
    async def send_payment_reminder(self, booking: Booking) -> None:
        """Send payment reminder to guest."""
        config = NOTIFICATION_CONFIG["payment_reminder"]
        
        # Get guest details
        guest = await self.db.get(User, booking.guest_id)
        if not guest:
            return
        
        # Prepare message content
        message = self._format_payment_reminder(booking, guest.language)
        
        # Send via configured channels
        if config["email"] and guest.email:
            await self._send_email(
                to_email=guest.email,
                subject=self._get_subject("payment_reminder", guest.language),
                body=message,
            )
        
        if config["telegram"] and guest.telegram_id:
            await self._send_telegram(
                chat_id=guest.telegram_id,
                text=message,
            )
        
        logger.info(
            "payment_reminder_sent",
            booking_id=booking.id,
            guest_id=guest.id,
        )
    
    async def notify_housekeeping(self, room_numbers: List[str]) -> None:
        """Notify housekeeping about rooms needing cleaning."""
        if not settings.TELEGRAM_CLEANER_CHAT_ID:
            return
        
        message = self._format_housekeeping_notification(room_numbers)
        
        await self._send_telegram(
            chat_id=settings.TELEGRAM_CLEANER_CHAT_ID,
            text=message,
        )
        
        logger.info(
            "housekeeping_notification_sent",
            room_count=len(room_numbers),
        )
    
    async def notify_manager(self, event: str, data: Dict) -> None:
        """Send notification to manager."""
        if not settings.TELEGRAM_MANAGER_CHAT_ID:
            return
        
        message = self._format_manager_notification(event, data)
        
        await self._send_telegram(
            chat_id=settings.TELEGRAM_MANAGER_CHAT_ID,
            text=message,
        )
        
        logger.info(
            "manager_notification_sent",
            event=event,
        )
    
    async def _send_email(
        self,
        to_email: str,
        subject: str,
        body: str,
        html: bool = False,
    ) -> None:
        """Send email notification."""
        if not settings.ENABLE_EMAIL_NOTIFICATIONS:
            return
        
        try:
            msg = MIMEMultipart()
            msg["From"] = f"{settings.SMTP_FROM_NAME} <{settings.SMTP_FROM_EMAIL}>"
            msg["To"] = to_email
            msg["Subject"] = subject
            
            msg.attach(MIMEText(body, "html" if html else "plain"))
            
            # Connect to SMTP server
            with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT) as server:
                if settings.SMTP_TLS:
                    server.starttls()
                if settings.SMTP_USER and settings.SMTP_PASSWORD:
                    server.login(settings.SMTP_USER, settings.SMTP_PASSWORD)
                server.send_message(msg)
            
        except Exception as e:
            logger.error(
                "email_send_failed",
                to_email=to_email,
                error=str(e),
            )
    
    async def _send_telegram(self, chat_id: str, text: str) -> None:
        """Send Telegram notification."""
        if not settings.ENABLE_TELEGRAM_BOT:
            return
        
        try:
            await telegram_bot.send_message(chat_id, text)
        except Exception as e:
            logger.error(
                "telegram_send_failed",
                chat_id=chat_id,
                error=str(e),
            )
    
    async def _send_sms(self, phone: str, text: str) -> None:
        """Send SMS notification."""
        if not settings.ENABLE_SMS_NOTIFICATIONS:
            return
        
        # TODO: Integrate with SMS gateway
        logger.info(
            "sms_mock_sent",
            phone=phone,
            text_length=len(text),
        )
    
    def _format_booking_confirmation(self, booking: Booking, language: str) -> str:
        """Format booking confirmation message."""
        if language == "ru":
            return f"""
Здравствуйте!

Ваше бронирование подтверждено.

📅 Номер брони: {booking.booking_ref}
🏨 Номер: {booking.room.room_number}
📆 Заезд: {booking.check_in_date}
📆 Выезд: {booking.check_out_date}
👥 Гостей: {booking.total_guests}
💰 Сумма: {booking.total_amount} KZT

Время заезда: 14:00
Время выезда: 12:00

С уважением,
Отель AI Reception
"""
        else:
            return f"""
Hello!

Your booking is confirmed.

📅 Booking reference: {booking.booking_ref}
🏨 Room: {booking.room.room_number}
📆 Check-in: {booking.check_in_date}
📆 Check-out: {booking.check_out_date}
👥 Guests: {booking.total_guests}
💰 Total: {booking.total_amount} KZT

Check-in time: 14:00
Check-out time: 12:00

Best regards,
Hotel AI Reception
"""
    
    def _format_check_in_reminder(self, booking: Booking, language: str) -> str:
        """Format check-in reminder message."""
        if language == "ru":
            return f"""
Добрый день!

Напоминаем, что завтра ваш заезд.

📅 Номер брони: {booking.booking_ref}
🏨 Номер: {booking.room.room_number}
📆 Дата заезда: {booking.check_in_date}
⏰ Время заезда: с 14:00

К оплате при заселении: {booking.balance_due} KZT

Ждем вас!
"""
        else:
            return f"""
Good day!

This is a reminder that your check-in is tomorrow.

📅 Booking reference: {booking.booking_ref}
🏨 Room: {booking.room.room_number}
📆 Check-in date: {booking.check_in_date}
⏰ Check-in time: from 14:00

Balance due at check-in: {booking.balance_due} KZT

We look forward to welcoming you!
"""
    
    def _format_check_out_reminder(self, booking: Booking, language: str) -> str:
        """Format check-out reminder message."""
        if language == "ru":
            return f"""
⏰ Напоминание о выезде

Уважаемый гость!
Время выезда: 12:00

Номер: {booking.room.room_number}

Пожалуйста, освободите номер вовремя.
Спасибо!
"""
        else:
            return f"""
⏰ Check-out reminder

Dear guest!
Check-out time: 12:00

Room: {booking.room.room_number}

Please vacate the room on time.
Thank you!
"""
    
    def _format_payment_reminder(self, booking: Booking, language: str) -> str:
        """Format payment reminder message."""
        if language == "ru":
            return f"""
Уважаемый гость!

Напоминаем о необходимости оплаты бронирования.

📅 Номер брони: {booking.booking_ref}
💰 К оплате: {booking.balance_due} KZT

Оплатить можно онлайн или при заселении.
"""
        else:
            return f"""
Dear guest!

This is a payment reminder for your booking.

📅 Booking reference: {booking.booking_ref}
💰 Balance due: {booking.balance_due} KZT

You can pay online or at check-in.
"""
    
    def _format_housekeeping_notification(self, room_numbers: List[str]) -> str:
        """Format housekeeping notification."""
        rooms_str = ", ".join(room_numbers)
        return f"""
🧹 Требуется уборка

Номера: {rooms_str}

Пожалуйста, начните уборку как можно скорее.
"""
    
    def _format_manager_notification(self, event: str, data: Dict) -> str:
        """Format manager notification."""
        notifications = {
            "overbooking": "⚠️ Обнаружен овербукинг!\n\nДата: {date}\nНомеров забронировано: {booked}\nНомеров доступно: {available}",
            "low_occupancy": "📊 Низкая загрузка\n\nДата: {date}\nЗагрузка: {occupancy}%",
            "payment_failed": "❌ Ошибка платежа\n\nБронь: {booking_ref}\nСумма: {amount} KZT\nПричина: {reason}",
            "vip_checkin": "⭐ VIP заезд\n\nГость: {guest_name}\nНомер: {room_number}\nДата: {check_in_date}",
        }
        
        template = notifications.get(event, "📢 {event}\n\n{data}")
        
        try:
            return template.format(**data)
        except:
            return f"📢 {event}\n\n{str(data)}"
    
    def _get_subject(self, notification_type: str, language: str) -> str:
        """Get email subject for notification type."""
        subjects = {
            "booking_confirmation": {
                "ru": "Подтверждение бронирования",
                "en": "Booking Confirmation",
            },
            "check_in_reminder": {
                "ru": "Напоминание о заезде",
                "en": "Check-in Reminder",
            },
            "payment_reminder": {
                "ru": "Напоминание об оплате",
                "en": "Payment Reminder",
            },
        }
        
        return subjects.get(notification_type, {}).get(language, notification_type)