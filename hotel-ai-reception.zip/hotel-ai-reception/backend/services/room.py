# path: backend/services/room.py
from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional, Tuple

from sqlalchemy import and_, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.exceptions import ConflictException, NotFoundException, ValidationException
from backend.models import Booking, BookingStatus, Room, RoomStatus, RoomType
from backend.schemas.room import RoomCreate, RoomUpdate


class RoomService:
    """Service for managing rooms."""
    
    def __init__(self, db: AsyncSession):
        self.db = db
    
    async def create_room(self, room_data: RoomCreate) -> Room:
        """Create a new room."""
        # Check if room number already exists
        stmt = select(Room).where(Room.room_number == room_data.room_number)
        existing = await self.db.execute(stmt)
        if existing.scalar_one_or_none():
            raise ConflictException(f"Room number {room_data.room_number} already exists")
        
        # Validate bed configuration
        if room_data.single_beds == 0 and room_data.double_beds == 0:
            raise ValidationException("Room must have at least one bed")
        
        # Create room
        room = Room(**room_data.model_dump())
        
        self.db.add(room)
        await self.db.commit()
        await self.db.refresh(room)
        
        return room
    
    async def get_room(self, room_id: int) -> Optional[Room]:
        """Get room by ID."""
        return await self.db.get(Room, room_id)
    
    async def get_room_by_number(self, room_number: str) -> Optional[Room]:
        """Get room by room number."""
        stmt = select(Room).where(Room.room_number == room_number)
        result = await self.db.execute(stmt)
        return result.scalar_one_or_none()
    
    async def list_rooms(
        self,
        offset: int = 0,
        limit: int = 20,
        status: Optional[str] = None,
        room_type: Optional[str] = None,
        floor: Optional[int] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        check_in_date: Optional[date] = None,
        check_out_date: Optional[date] = None,
    ) -> Tuple[List[Room], int]:
        """List rooms with filters."""
        query = select(Room)
        count_query = select(func.count(Room.id))
        
        # Apply filters
        if status:
            try:
                status_enum = RoomStatus(status)
                query = query.where(Room.status == status_enum)
                count_query = count_query.where(Room.status == status_enum)
            except ValueError:
                pass
        
        if room_type:
            try:
                type_enum = RoomType(room_type)
                query = query.where(Room.room_type == type_enum)
                count_query = count_query.where(Room.room_type == type_enum)
            except ValueError:
                pass
        
        if floor is not None:
            query = query.where(Room.floor == floor)
            count_query = count_query.where(Room.floor == floor)
        
        if min_price is not None:
            query = query.where(Room.base_price >= min_price)
            count_query = count_query.where(Room.base_price >= min_price)
        
        if max_price is not None:
            query = query.where(Room.base_price <= max_price)
            count_query = count_query.where(Room.base_price <= max_price)
        
        # Filter by availability for dates
        if check_in_date and check_out_date:
            # Subquery to find rooms with conflicting bookings
            booked_rooms = (
                select(Booking.room_id)
                .where(
                    and_(
                        Booking.status.in_([
                            BookingStatus.CONFIRMED,
                            BookingStatus.CHECKED_IN,
                        ]),
                        or_(
                            and_(
                                Booking.check_in_date < check_out_date,
                                Booking.check_out_date > check_in_date,
                            ),
                            and_(
                                Booking.check_in_date >= check_in_date,
                                Booking.check_in_date < check_out_date,
                            ),
                        ),
                    )
                )
            )
            
            query = query.where(
                and_(
                    ~Room.id.in_(booked_rooms),
                    Room.status == RoomStatus.AVAILABLE,
                    Room.is_active == True,
                )
            )
            count_query = count_query.where(
                and_(
                    ~Room.id.in_(booked_rooms),
                    Room.status == RoomStatus.AVAILABLE,
                    Room.is_active == True,
                )
            )
        
        # Only show active rooms
        query = query.where(Room.is_active == True)
        count_query = count_query.where(Room.is_active == True)
        
        # Get total count
        total = await self.db.scalar(count_query)
        
        # Apply pagination and ordering
        query = query.order_by(Room.room_number).offset(offset).limit(limit)
        
        # Execute query
        result = await self.db.execute(query)
        rooms = result.scalars().all()
        
        return rooms, total
    
    async def get_available_rooms(
        self,
        check_in_date: date,
        check_out_date: date,
        room_type: Optional[str] = None,
        max_occupancy: Optional[int] = None,
    ) -> List[Room]:
        """Get available rooms for specific dates."""
        # Base query
        query = select(Room).where(
            and_(
                Room.status == RoomStatus.AVAILABLE,
                Room.is_active == True,
            )
        )
        
        # Filter by room type
        if room_type:
            try:
                type_enum = RoomType(room_type)
                query = query.where(Room.room_type == type_enum)
            except ValueError:
                pass
        
        # Filter by occupancy
        if max_occupancy:
            query = query.where(Room.max_occupancy >= max_occupancy)
        
        # Exclude booked rooms
        booked_rooms = (
            select(Booking.room_id)
            .where(
                and_(
                    Booking.status.in_([
                        BookingStatus.CONFIRMED,
                        BookingStatus.CHECKED_IN,
                    ]),
                    or_(
                        and_(
                            Booking.check_in_date < check_out_date,
                            Booking.check_out_date > check_in_date,
                        ),
                        and_(
                            Booking.check_in_date >= check_in_date,
                            Booking.check_in_date < check_out_date,
                        ),
                    ),
                )
            )
        )
        
        query = query.where(~Room.id.in_(booked_rooms))
        query = query.order_by(Room.base_price)
        
        result = await self.db.execute(query)
        return result.scalars().all()
    
    async def update_room(self, room_id: int, room_update: RoomUpdate) -> Room:
        """Update room details."""
        room = await self.get_room(room_id)
        if not room:
            raise NotFoundException(f"Room {room_id} not found")
        
        # Check if new room number conflicts
        if room_update.room_number and room_update.room_number != room.room_number:
            existing = await self.get_room_by_number(room_update.room_number)
            if existing:
                raise ConflictException(f"Room number {room_update.room_number} already exists")
        
        # Update fields
        update_data = room_update.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(room, field, value)
        
        room.updated_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(room)
        
        return room
    
    async def set_room_price(self, room_id: int, price: float) -> Room:
        """Set room price."""
        room = await self.get_room(room_id)
        if not room:
            raise NotFoundException(f"Room {room_id} not found")
        
        if price < 0:
            raise ValidationException("Price cannot be negative")
        
        room.base_price = Decimal(str(price))
        room.updated_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(room)
        
        return room
    
    async def mark_room_cleaned(self, room_id: int, cleaned_by_id: int) -> Room:
        """Mark room as cleaned."""
        room = await self.get_room(room_id)
        if not room:
            raise NotFoundException(f"Room {room_id} not found")
        
        if room.status != RoomStatus.CLEANING:
            raise ConflictException(f"Room {room_id} is not in cleaning status")
        
        room.status = RoomStatus.AVAILABLE
        room.last_cleaned_at = datetime.utcnow()
        room.updated_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(room)
        
        # TODO: Log cleaning activity
        
        return room
    
    async def set_maintenance_status(
        self,
        room_id: int,
        maintenance: bool,
        notes: Optional[str] = None,
        updated_by_id: Optional[int] = None,
    ) -> Room:
        """Set room maintenance status."""
        room = await self.get_room(room_id)
        if not room:
            raise NotFoundException(f"Room {room_id} not found")
        
        if maintenance:
            # Check if room is occupied
            if room.status == RoomStatus.OCCUPIED:
                raise ConflictException("Cannot set maintenance for occupied room")
            
            room.status = RoomStatus.MAINTENANCE
            room.last_maintenance_at = datetime.utcnow()
            if notes:
                room.internal_notes = notes
        else:
            if room.status == RoomStatus.MAINTENANCE:
                room.status = RoomStatus.AVAILABLE
        
        room.updated_at = datetime.utcnow()
        
        await self.db.commit()
        await self.db.refresh(room)
        
        return room
    
    async def get_rooms_needing_cleaning(self) -> List[Room]:
        """Get rooms that need cleaning."""
        stmt = select(Room).where(Room.status == RoomStatus.CLEANING)
        result = await self.db.execute(stmt)
        return result.scalars().all()
    
    async def get_rooms_in_maintenance(self) -> List[Room]:
        """Get rooms in maintenance."""
        stmt = select(Room).where(Room.status == RoomStatus.MAINTENANCE)
        result = await self.db.execute(stmt)
        return result.scalars().all()