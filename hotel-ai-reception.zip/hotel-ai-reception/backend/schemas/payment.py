# path: backend/schemas/payment.py
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.models.payment import PaymentMethod, PaymentStatus


class PaymentBase(BaseModel):
    """Base payment schema."""
    
    booking_id: int
    amount: Decimal = Field(..., ge=0, decimal_places=2)
    currency: str = Field("KZT", pattern="^[A-Z]{3}$")
    payment_method: PaymentMethod
    notes: Optional[str] = None


class PaymentCreate(PaymentBase):
    """Payment creation schema."""
    
    card_last_four: Optional[str] = Field(None, pattern="^[0-9]{4}$")
    card_brand: Optional[str] = Field(None, max_length=20)
    
    @field_validator("payment_method")
    @classmethod
    def validate_card_info(cls, v: PaymentMethod, info: Dict[str, Any]) -> PaymentMethod:
        """Validate card info for card payments."""
        if v == PaymentMethod.CARD:
            if not info.data.get("card_last_four") or not info.data.get("card_brand"):
                raise ValueError("Card information required for card payments")
        return v


class PaymentResponse(PaymentBase):
    """Payment response schema."""
    
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    payment_ref: str
    status: PaymentStatus
    transaction_id: Optional[str] = None
    card_last_four: Optional[str] = None
    card_brand: Optional[str] = None
    gateway_response: Optional[Dict[str, Any]] = None
    is_successful: bool
    is_refundable: bool
    net_amount: Decimal
    refund_amount: Optional[Decimal] = None
    refund_reason: Optional[str] = None
    refunded_at: Optional[datetime] = None
    processed_at: Optional[datetime] = None
    failed_at: Optional[datetime] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    # Nested relations
    booking_ref: Optional[str] = None
    guest_name: Optional[str] = None
    
    @classmethod
    def from_orm(cls, obj: Any) -> "PaymentResponse":
        """Create response from ORM object."""
        data = {
            "id": obj.id,
            "payment_ref": obj.payment_ref,
            "booking_id": obj.booking_id,
            "amount": obj.amount,
            "currency": obj.currency,
            "payment_method": obj.payment_method,
            "status": obj.status,
            "transaction_id": obj.transaction_id,
            "card_last_four": obj.card_last_four,
            "card_brand": obj.card_brand,
            "gateway_response": obj.gateway_response,
            "is_successful": obj.is_successful,
            "is_refundable": obj.is_refundable,
            "net_amount": obj.net_amount,
            "refund_amount": obj.refund_amount,
            "refund_reason": obj.refund_reason,
            "refunded_at": obj.refunded_at,
            "processed_at": obj.processed_at,
            "failed_at": obj.failed_at,
            "error_code": obj.error_code,
            "error_message": obj.error_message,
            "notes": obj.notes,
            "created_at": obj.created_at,
            "updated_at": obj.updated_at,
        }
        
        # Add nested relations if loaded
        if hasattr(obj, "booking") and obj.booking:
            data["booking_ref"] = obj.booking.booking_ref
            if hasattr(obj.booking, "guest") and obj.booking.guest:
                data["guest_name"] = obj.booking.guest.full_name
        
        return cls(**data)


class PaymentListResponse(BaseModel):
    """Payment list response schema."""
    
    items: List[PaymentResponse]
    total: int
    page: int
    page_size: int
    
    @property
    def total_pages(self) -> int:
        """Calculate total pages."""
        return (self.total + self.page_size - 1) // self.page_size


class RefundRequest(BaseModel):
    """Refund request schema."""
    
    amount: Decimal = Field(..., ge=0, decimal_places=2)
    reason: str = Field(..., min_length=1, max_length=500)
    
    @field_validator("amount")
    @classmethod
    def validate_amount(cls, v: Decimal) -> Decimal:
        """Validate refund amount."""
        if v <= 0:
            raise ValueError("Refund amount must be greater than 0")
        return v


class PaymentSummary(BaseModel):
    """Payment summary schema."""
    
    total_amount: Decimal
    paid_amount: Decimal
    pending_amount: Decimal
    refunded_amount: Decimal
    balance_due: Decimal
    payment_count: int
    last_payment_date: Optional[datetime] = None