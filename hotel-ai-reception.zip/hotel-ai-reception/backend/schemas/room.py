# path: backend/schemas/room.py
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.models.room import RoomStatus, RoomType


class RoomBase(BaseModel):
    """Base room schema."""
    
    room_number: str = Field(..., min_length=1, max_length=10)
    floor: int = Field(..., ge=0)
    building: Optional[str] = Field(None, max_length=50)
    room_type: RoomType
    max_occupancy: int = Field(..., ge=1, le=10)
    single_beds: int = Field(0, ge=0, le=5)
    double_beds: int = Field(0, ge=0, le=3)
    base_price: Decimal = Field(..., ge=0, decimal_places=2)
    area_sqm: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    has_balcony: bool = False
    has_kitchen: bool = False
    has_bathtub: bool = False
    has_workspace: bool = False
    is_smoking: bool = False
    view_type: Optional[str] = Field(None, max_length=50)
    amenities: Dict[str, Any] = Field(default_factory=dict)
    description: Optional[str] = None
    internal_notes: Optional[str] = None


class RoomCreate(RoomBase):
    """Room creation schema."""
    
    status: RoomStatus = RoomStatus.AVAILABLE
    is_active: bool = True


class RoomUpdate(BaseModel):
    """Room update schema."""
    
    model_config = ConfigDict(validate_assignment=True)
    
    room_number: Optional[str] = Field(None, min_length=1, max_length=10)
    floor: Optional[int] = Field(None, ge=0)
    building: Optional[str] = Field(None, max_length=50)
    room_type: Optional[RoomType] = None
    status: Optional[RoomStatus] = None
    max_occupancy: Optional[int] = Field(None, ge=1, le=10)
    single_beds: Optional[int] = Field(None, ge=0, le=5)
    double_beds: Optional[int] = Field(None, ge=0, le=3)
    base_price: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    area_sqm: Optional[Decimal] = Field(None, ge=0, decimal_places=2)
    has_balcony: Optional[bool] = None
    has_kitchen: Optional[bool] = None
    has_bathtub: Optional[bool] = None
    has_workspace: Optional[bool] = None
    is_smoking: Optional[bool] = None
    view_type: Optional[str] = Field(None, max_length=50)
    amenities: Optional[Dict[str, Any]] = None
    description: Optional[str] = None
    internal_notes: Optional[str] = None
    is_active: Optional[bool] = None
    cleaning_duration_minutes: Optional[int] = Field(None, ge=15, le=180)


class RoomResponse(RoomBase):
    """Room response schema."""
    
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    status: RoomStatus
    is_active: bool
    total_beds: int
    is_available: bool
    needs_cleaning: bool
    needs_maintenance: bool
    last_cleaned_at: Optional[datetime] = None
    last_maintenance_at: Optional[datetime] = None
    next_maintenance_at: Optional[datetime] = None
    cleaning_duration_minutes: int
    created_at: datetime
    updated_at: datetime


class RoomListResponse(BaseModel):
    """Room list response schema."""
    
    items: List[RoomResponse]
    total: int
    page: int
    page_size: int
    
    @property
    def total_pages(self) -> int:
        """Calculate total pages."""
        return (self.total + self.page_size - 1) // self.page_size


class RoomAvailabilityRequest(BaseModel):
    """Room availability request schema."""
    
    check_in_date: datetime
    check_out_date: datetime
    room_type: Optional[RoomType] = None
    max_occupancy: Optional[int] = Field(None, ge=1)
    
    @field_validator("check_out_date")
    @classmethod
    def validate_dates(cls, v: datetime, info: Dict[str, Any]) -> datetime:
        """Validate check-out is after check-in."""
        if "check_in_date" in info.data and v <= info.data["check_in_date"]:
            raise ValueError("Check-out date must be after check-in date")
        return v