# path: backend/schemas/__init__.py
"""Pydantic schemas for Hotel AI Reception."""

from backend.schemas.booking import (
    BookingCreate,
    BookingListResponse,
    BookingResponse,
    BookingUpdate,
)
from backend.schemas.chat import ChatMessage, ChatMessageType
from backend.schemas.payment import (
    PaymentCreate,
    PaymentListResponse,
    PaymentResponse,
    RefundRequest,
)
from backend.schemas.room import (
    RoomCreate,
    RoomListResponse,
    RoomResponse,
    RoomUpdate,
)

__all__ = [
    # Booking schemas
    "BookingCreate",
    "BookingUpdate",
    "BookingResponse",
    "BookingListResponse",
    # Room schemas
    "RoomCreate",
    "RoomUpdate",
    "RoomResponse",
    "RoomListResponse",
    # Payment schemas
    "PaymentCreate",
    "PaymentResponse",
    "PaymentListResponse",
    "RefundRequest",
    # Chat schemas
    "ChatMessage",
    "ChatMessageType",
]