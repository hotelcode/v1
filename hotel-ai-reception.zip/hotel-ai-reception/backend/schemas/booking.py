# path: backend/schemas/booking.py
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from backend.models.booking import BookingStatus


class BookingBase(BaseModel):
    """Base booking schema."""
    
    guest_id: int
    room_id: int
    check_in_date: date
    check_out_date: date
    num_adults: int = Field(1, ge=1, le=10)
    num_children: int = Field(0, ge=0, le=10)
    special_requests: Optional[str] = None
    guest_preferences: Dict[str, Any] = Field(default_factory=dict)
    guest_email: Optional[EmailStr] = None
    guest_phone: Optional[str] = Field(None, pattern=r"^\+?[1-9]\d{1,14}$")
    booking_source: Optional[str] = Field(None, max_length=50)
    internal_notes: Optional[str] = None
    
    @field_validator("check_out_date")
    @classmethod
    def validate_dates(cls, v: date, info: Dict[str, Any]) -> date:
        """Validate check-out is after check-in."""
        if "check_in_date" in info.data and v <= info.data["check_in_date"]:
            raise ValueError("Check-out date must be after check-in date")
        return v
    
    @field_validator("num_adults", "num_children")
    @classmethod
    def validate_occupancy(cls, v: int, info: Dict[str, Any]) -> int:
        """Validate total occupancy."""
        if "num_adults" in info.data and "num_children" in info.data:
            total = info.data["num_adults"] + info.data["num_children"]
            if total > 10:
                raise ValueError("Total occupancy cannot exceed 10 guests")
        return v


class BookingCreate(BookingBase):
    """Booking creation schema."""
    
    room_rate: Optional[Decimal] = None  # If not provided, use current room rate
    requires_prepayment: bool = True
    is_guaranteed: bool = False


class BookingUpdate(BaseModel):
    """Booking update schema."""
    
    model_config = ConfigDict(validate_assignment=True)
    
    check_in_date: Optional[date] = None
    check_out_date: Optional[date] = None
    num_adults: Optional[int] = Field(None, ge=1, le=10)
    num_children: Optional[int] = Field(None, ge=0, le=10)
    special_requests: Optional[str] = None
    guest_preferences: Optional[Dict[str, Any]] = None
    guest_email: Optional[EmailStr] = None
    guest_phone: Optional[str] = Field(None, pattern=r"^\+?[1-9]\d{1,14}$")
    internal_notes: Optional[str] = None
    status: Optional[BookingStatus] = None


class BookingResponse(BookingBase):
    """Booking response schema."""
    
    model_config = ConfigDict(from_attributes=True)
    
    id: int
    booking_ref: str
    status: BookingStatus
    room_rate: Decimal
    total_amount: Decimal
    paid_amount: Decimal
    balance_due: Decimal
    nights: int
    total_guests: int
    is_prepaid: bool
    requires_prepayment: bool
    is_guaranteed: bool
    is_paid_in_full: bool
    is_active: bool
    can_cancel: bool
    can_check_in: bool
    can_check_out: bool
    actual_check_in: Optional[datetime] = None
    actual_check_out: Optional[datetime] = None
    cancelled_at: Optional[datetime] = None
    cancellation_reason: Optional[str] = None
    refund_amount: Optional[Decimal] = None
    created_at: datetime
    updated_at: datetime
    
    # Nested relations
    room_number: Optional[str] = None
    room_type: Optional[str] = None
    guest_name: Optional[str] = None
    
    @classmethod
    def from_orm(cls, obj: Any) -> "BookingResponse":
        """Create response from ORM object."""
        data = {
            "id": obj.id,
            "booking_ref": obj.booking_ref,
            "guest_id": obj.guest_id,
            "room_id": obj.room_id,
            "check_in_date": obj.check_in_date,
            "check_out_date": obj.check_out_date,
            "status": obj.status,
            "num_adults": obj.num_adults,
            "num_children": obj.num_children,
            "room_rate": obj.room_rate,
            "total_amount": obj.total_amount,
            "paid_amount": obj.paid_amount,
            "balance_due": obj.balance_due,
            "nights": obj.nights,
            "total_guests": obj.total_guests,
            "special_requests": obj.special_requests,
            "guest_preferences": obj.guest_preferences,
            "guest_email": obj.guest_email,
            "guest_phone": obj.guest_phone,
            "booking_source": obj.booking_source,
            "is_prepaid": obj.is_prepaid,
            "requires_prepayment": obj.requires_prepayment,
            "is_guaranteed": obj.is_guaranteed,
            "is_paid_in_full": obj.is_paid_in_full,
            "is_active": obj.is_active,
            "can_cancel": obj.can_cancel,
            "can_check_in": obj.can_check_in,
            "can_check_out": obj.can_check_out,
            "actual_check_in": obj.actual_check_in,
            "actual_check_out": obj.actual_check_out,
            "cancelled_at": obj.cancelled_at,
            "cancellation_reason": obj.cancellation_reason,
            "refund_amount": obj.refund_amount,
            "internal_notes": obj.internal_notes,
            "created_at": obj.created_at,
            "updated_at": obj.updated_at,
        }
        
        # Add nested relations if loaded
        if hasattr(obj, "room") and obj.room:
            data["room_number"] = obj.room.room_number
            data["room_type"] = obj.room.room_type.value
        
        if hasattr(obj, "guest") and obj.guest:
            data["guest_name"] = obj.guest.full_name
        
        return cls(**data)


class BookingListResponse(BaseModel):
    """Booking list response schema."""
    
    items: List[BookingResponse]
    total: int
    page: int
    page_size: int
    
    @property
    def total_pages(self) -> int:
        """Calculate total pages."""
        return (self.total + self.page_size - 1) // self.page_size