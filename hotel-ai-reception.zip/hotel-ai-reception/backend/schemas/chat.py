# path: backend/schemas/chat.py
import enum
from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class ChatMessageType(str, enum.Enum):
    """Chat message type enumeration."""
    
    TEXT = "text"
    AUDIO = "audio"
    IMAGE = "image"
    TYPING = "typing"
    SYSTEM = "system"
    ERROR = "error"
    TRANSCRIPTION = "transcription"


class ChatMessage(BaseModel):
    """Chat message schema."""
    
    type: ChatMessageType
    content: str
    language: str = Field("ru", pattern="^[a-z]{2}$")
    metadata: Optional[Dict[str, Any]] = None
    audio_response: bool = False
    
    class Config:
        use_enum_values = True


class ChatResponse(BaseModel):
    """Chat response schema."""
    
    type: ChatMessageType
    content: str
    timestamp: datetime
    metadata: Optional[Dict[str, Any]] = None


class ChatSession(BaseModel):
    """Chat session schema."""
    
    session_id: str
    user_id: int
    started_at: datetime
    last_message_at: Optional[datetime] = None
    message_count: int = 0
    language: str = "ru"
    context: Dict[str, Any] = Field(default_factory=dict)


class AudioTranscriptionRequest(BaseModel):
    """Audio transcription request schema."""
    
    audio_data: str  # Base64 encoded audio
    format: str = "wav"
    language: Optional[str] = None  # Auto-detect if not provided


class AudioTranscriptionResponse(BaseModel):
    """Audio transcription response schema."""
    
    text: str
    language: str
    confidence: Optional[float] = None
    duration_seconds: Optional[float] = None


class TextToSpeechRequest(BaseModel):
    """Text-to-speech request schema."""
    
    text: str = Field(..., min_length=1, max_length=1000)
    language: str = Field("ru", pattern="^[a-z]{2}$")
    voice: Optional[str] = None
    speed: float = Field(1.0, ge=0.5, le=2.0)


class TextToSpeechResponse(BaseModel):
    """Text-to-speech response schema."""
    
    audio_url: str
    duration_seconds: Optional[float] = None
    format: str = "wav"


class ChatIntent(str, enum.Enum):
    """Chat intent enumeration."""
    
    BOOKING_CREATE = "booking_create"
    BOOKING_CANCEL = "booking_cancel"
    BOOKING_MODIFY = "booking_modify"
    BOOKING_INFO = "booking_info"
    ROOM_INFO = "room_info"
    ROOM_AVAILABILITY = "room_availability"
    PAYMENT_INFO = "payment_info"
    PAYMENT_MAKE = "payment_make"
    GENERAL_INFO = "general_info"
    COMPLAINT = "complaint"
    UNKNOWN = "unknown"


class ChatContext(BaseModel):
    """Chat context schema."""
    
    intent: ChatIntent = ChatIntent.UNKNOWN
    entities: Dict[str, Any] = Field(default_factory=dict)
    booking_id: Optional[int] = None
    room_id: Optional[int] = None
    check_in_date: Optional[datetime] = None
    check_out_date: Optional[datetime] = None
    guest_count: Optional[int] = None
    
    def update_from_message(self, message: str, language: str = "ru") -> None:
        """Update context from message (placeholder for NLU)."""
        # This would integrate with actual NLU service
        # For now, just basic keyword detection
        message_lower = message.lower()
        
        if any(word in message_lower for word in ["бронь", "забронировать", "booking", "reserve"]):
            self.intent = ChatIntent.BOOKING_CREATE
        elif any(word in message_lower for word in ["отменить", "отмена", "cancel"]):
            self.intent = ChatIntent.BOOKING_CANCEL
        elif any(word in message_lower for word in ["изменить", "перенести", "modify", "change"]):
            self.intent = ChatIntent.BOOKING_MODIFY
        elif any(word in message_lower for word in ["номер", "комната", "room"]):
            self.intent = ChatIntent.ROOM_INFO
        elif any(word in message_lower for word in ["оплата", "платеж", "payment", "pay"]):
            self.intent = ChatIntent.PAYMENT_INFO
        elif any(word in message_lower for word in ["жалоба", "проблема", "complaint", "issue"]):
            self.intent = ChatIntent.COMPLAINT