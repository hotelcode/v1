# path: backend/models/room.py
import enum
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, List, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    Integer,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.core.database import Base

if TYPE_CHECKING:
    from backend.models.booking import Booking


class RoomType(str, enum.Enum):
    """Room type enumeration."""
    
    SINGLE = "single"
    DOUBLE = "double"
    TWIN = "twin"
    SUITE = "suite"
    DELUXE = "deluxe"
    VIP = "vip"


class RoomStatus(str, enum.Enum):
    """Room status enumeration."""
    
    AVAILABLE = "available"
    OCCUPIED = "occupied"
    RESERVED = "reserved"
    CLEANING = "cleaning"
    MAINTENANCE = "maintenance"


class Room(Base):
    """Room model."""
    
    __tablename__ = "rooms"
    
    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    
    # Room identification
    room_number: Mapped[str] = mapped_column(String(10), unique=True, nullable=False, index=True)
    floor: Mapped[int] = mapped_column(Integer, nullable=False)
    building: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Room characteristics
    room_type: Mapped[RoomType] = mapped_column(
        Enum(RoomType, native_enum=False),
        nullable=False,
        index=True
    )
    status: Mapped[RoomStatus] = mapped_column(
        Enum(RoomStatus, native_enum=False),
        default=RoomStatus.AVAILABLE,
        nullable=False,
        index=True
    )
    
    # Capacity
    max_occupancy: Mapped[int] = mapped_column(Integer, nullable=False)
    single_beds: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    double_beds: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    
    # Pricing
    base_price: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        comment="Base price per night in KZT"
    )
    
    # Features and amenities
    area_sqm: Mapped[Optional[Decimal]] = mapped_column(Numeric(6, 2))
    has_balcony: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    has_kitchen: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    has_bathtub: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    has_workspace: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_smoking: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # View type
    view_type: Mapped[Optional[str]] = mapped_column(String(50))  # city, garden, pool, etc.
    
    # Additional amenities as JSON
    amenities: Mapped[Optional[dict]] = mapped_column(
        JSON,
        default=dict,
        comment="Additional amenities like minibar, safe, etc."
    )
    
    # Description and notes
    description: Mapped[Optional[str]] = mapped_column(Text)
    internal_notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Maintenance tracking
    last_maintenance_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    next_maintenance_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Cleaning tracking
    last_cleaned_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    cleaning_duration_minutes: Mapped[int] = mapped_column(Integer, default=30, nullable=False)
    
    # Availability
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )
    
    # Relationships
    bookings: Mapped[List["Booking"]] = relationship(
        "Booking",
        back_populates="room",
        cascade="all, delete-orphan"
    )
    
    @property
    def total_beds(self) -> int:
        """Get total number of beds."""
        return self.single_beds + (self.double_beds * 2)
    
    @property
    def is_available(self) -> bool:
        """Check if room is available."""
        return self.status == RoomStatus.AVAILABLE and self.is_active
    
    @property
    def needs_cleaning(self) -> bool:
        """Check if room needs cleaning."""
        return self.status == RoomStatus.CLEANING
    
    @property
    def needs_maintenance(self) -> bool:
        """Check if room needs maintenance."""
        if self.status == RoomStatus.MAINTENANCE:
            return True
        if self.next_maintenance_at and self.next_maintenance_at <= datetime.now():
            return True
        return False
    
    def __repr__(self) -> str:
        return f"<Room(id={self.id}, number='{self.room_number}', type={self.room_type.value}, status={self.status.value})>"