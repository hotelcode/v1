# path: backend/models/user.py
import enum
from datetime import datetime
from typing import TYPE_CHECKING, List, Optional

from sqlalchemy import Boolean, DateTime, Enum, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.core.database import Base

if TYPE_CHECKING:
    from backend.models.booking import Booking


class UserRole(str, enum.Enum):
    """User roles enumeration."""
    
    GUEST = "guest"
    HOUSEKEEPER = "housekeeper"
    MANAGER = "manager"
    ADMIN = "admin"


class User(Base):
    """User model."""
    
    __tablename__ = "users"
    
    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    
    # Authentication fields
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    
    # Profile fields
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    middle_name: Mapped[Optional[str]] = mapped_column(String(100))
    
    # Role and permissions
    role: Mapped[UserRole] = mapped_column(
        Enum(UserRole, native_enum=False),
        default=UserRole.GUEST,
        nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Telegram integration
    telegram_id: Mapped[Optional[str]] = mapped_column(String(50), unique=True, index=True)
    telegram_username: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Preferences
    language: Mapped[str] = mapped_column(String(2), default="ru", nullable=False)
    timezone: Mapped[str] = mapped_column(String(50), default="Asia/Almaty", nullable=False)
    
    # Additional info
    notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Relationships
    bookings: Mapped[List["Booking"]] = relationship(
        "Booking",
        back_populates="guest",
        cascade="all, delete-orphan"
    )
    
    @property
    def full_name(self) -> str:
        """Get user's full name."""
        parts = [self.first_name]
        if self.middle_name:
            parts.append(self.middle_name)
        parts.append(self.last_name)
        return " ".join(parts)
    
    @property
    def is_staff(self) -> bool:
        """Check if user is staff member."""
        return self.role in [UserRole.HOUSEKEEPER, UserRole.MANAGER, UserRole.ADMIN]
    
    @property
    def is_manager(self) -> bool:
        """Check if user is manager or admin."""
        return self.role in [UserRole.MANAGER, UserRole.ADMIN]
    
    def __repr__(self) -> str:
        return f"<User(id={self.id}, email='{self.email}', role={self.role.value})>"