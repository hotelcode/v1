# path: backend/models/booking.py
import enum
from datetime import date, datetime
from decimal import Decimal
from typing import TYPE_CHECKING, List, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.core.database import Base

if TYPE_CHECKING:
    from backend.models.payment import Payment
    from backend.models.room import Room
    from backend.models.user import User


class BookingStatus(str, enum.Enum):
    """Booking status enumeration."""
    
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CHECKED_IN = "checked_in"
    CHECKED_OUT = "checked_out"
    CANCELLED = "cancelled"
    NO_SHOW = "no_show"


class Booking(Base):
    """Booking model."""
    
    __tablename__ = "bookings"
    
    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    
    # Booking reference
    booking_ref: Mapped[str] = mapped_column(
        String(20),
        unique=True,
        nullable=False,
        index=True,
        comment="Unique booking reference number"
    )
    
    # Foreign keys
    guest_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"),
        nullable=False,
        index=True
    )
    room_id: Mapped[int] = mapped_column(
        ForeignKey("rooms.id", ondelete="RESTRICT"),
        nullable=False,
        index=True
    )
    
    # Booking dates
    check_in_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    check_out_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    
    # Actual check-in/out times
    actual_check_in: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    actual_check_out: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Status
    status: Mapped[BookingStatus] = mapped_column(
        Enum(BookingStatus, native_enum=False),
        default=BookingStatus.PENDING,
        nullable=False,
        index=True
    )
    
    # Guest details
    num_adults: Mapped[int] = mapped_column(Integer, default=1, nullable=False)
    num_children: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    
    # Pricing
    room_rate: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        comment="Room rate per night at time of booking"
    )
    total_amount: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        comment="Total booking amount"
    )
    paid_amount: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        default=Decimal("0"),
        nullable=False,
        comment="Amount already paid"
    )
    
    # Special requests and preferences
    special_requests: Mapped[Optional[str]] = mapped_column(Text)
    guest_preferences: Mapped[Optional[dict]] = mapped_column(
        JSON,
        default=dict,
        comment="Guest preferences like bed type, floor, etc."
    )
    
    # Contact during stay
    guest_email: Mapped[Optional[str]] = mapped_column(String(255))
    guest_phone: Mapped[Optional[str]] = mapped_column(String(20))
    
    # Source and channel
    booking_source: Mapped[Optional[str]] = mapped_column(
        String(50),
        comment="Source of booking: direct, website, phone, etc."
    )
    
    # Cancellation info
    cancelled_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    cancellation_reason: Mapped[Optional[str]] = mapped_column(Text)
    refund_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    
    # Flags
    is_prepaid: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    requires_prepayment: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_guaranteed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    
    # Internal notes
    internal_notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )
    
    # Relationships
    guest: Mapped["User"] = relationship("User", back_populates="bookings")
    room: Mapped["Room"] = relationship("Room", back_populates="bookings")
    payments: Mapped[List["Payment"]] = relationship(
        "Payment",
        back_populates="booking",
        cascade="all, delete-orphan"
    )
    
    @property
    def nights(self) -> int:
        """Calculate number of nights."""
        return (self.check_out_date - self.check_in_date).days
    
    @property
    def total_guests(self) -> int:
        """Get total number of guests."""
        return self.num_adults + self.num_children
    
    @property
    def balance_due(self) -> Decimal:
        """Calculate balance due."""
        return self.total_amount - self.paid_amount
    
    @property
    def is_paid_in_full(self) -> bool:
        """Check if booking is fully paid."""
        return self.balance_due <= Decimal("0")
    
    @property
    def is_active(self) -> bool:
        """Check if booking is active."""
        return self.status in [
            BookingStatus.PENDING,
            BookingStatus.CONFIRMED,
            BookingStatus.CHECKED_IN
        ]
    
    @property
    def can_cancel(self) -> bool:
        """Check if booking can be cancelled."""
        return self.status in [BookingStatus.PENDING, BookingStatus.CONFIRMED]
    
    @property
    def can_check_in(self) -> bool:
        """Check if guest can check in."""
        return (
            self.status == BookingStatus.CONFIRMED
            and date.today() >= self.check_in_date
            and not self.actual_check_in
        )
    
    @property
    def can_check_out(self) -> bool:
        """Check if guest can check out."""
        return self.status == BookingStatus.CHECKED_IN and not self.actual_check_out
    
    def __repr__(self) -> str:
        return f"<Booking(id={self.id}, ref='{self.booking_ref}', status={self.status.value})>"