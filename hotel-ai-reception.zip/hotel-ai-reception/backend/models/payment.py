# path: backend/models/payment.py
import enum
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Optional

from sqlalchemy import (
    JSON,
    DateTime,
    Enum,
    ForeignKey,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from backend.core.database import Base

if TYPE_CHECKING:
    from backend.models.booking import Booking


class PaymentMethod(str, enum.Enum):
    """Payment method enumeration."""
    
    CASH = "cash"
    CARD = "card"
    BANK_TRANSFER = "bank_transfer"
    ONLINE = "online"


class PaymentStatus(str, enum.Enum):
    """Payment status enumeration."""
    
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"


class Payment(Base):
    """Payment model."""
    
    __tablename__ = "payments"
    
    # Primary key
    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    
    # Payment reference
    payment_ref: Mapped[str] = mapped_column(
        String(50),
        unique=True,
        nullable=False,
        index=True,
        comment="Unique payment reference"
    )
    
    # Foreign key
    booking_id: Mapped[int] = mapped_column(
        ForeignKey("bookings.id", ondelete="RESTRICT"),
        nullable=False,
        index=True
    )
    
    # Payment details
    amount: Mapped[Decimal] = mapped_column(
        Numeric(10, 2),
        nullable=False,
        comment="Payment amount"
    )
    currency: Mapped[str] = mapped_column(
        String(3),
        default="KZT",
        nullable=False,
        comment="Currency code"
    )
    
    # Method and status
    payment_method: Mapped[PaymentMethod] = mapped_column(
        Enum(PaymentMethod, native_enum=False),
        nullable=False,
        index=True
    )
    status: Mapped[PaymentStatus] = mapped_column(
        Enum(PaymentStatus, native_enum=False),
        default=PaymentStatus.PENDING,
        nullable=False,
        index=True
    )
    
    # Transaction details
    transaction_id: Mapped[Optional[str]] = mapped_column(
        String(100),
        comment="External transaction ID"
    )
    gateway_response: Mapped[Optional[dict]] = mapped_column(
        JSON,
        comment="Payment gateway response"
    )
    
    # Card details (masked)
    card_last_four: Mapped[Optional[str]] = mapped_column(String(4))
    card_brand: Mapped[Optional[str]] = mapped_column(String(20))
    
    # Refund information
    refund_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    refund_reason: Mapped[Optional[str]] = mapped_column(Text)
    refunded_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Processing timestamps
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    failed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Error information
    error_code: Mapped[Optional[str]] = mapped_column(String(50))
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    
    # Internal notes
    notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Timestamps
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )
    
    # Relationships
    booking: Mapped["Booking"] = relationship("Booking", back_populates="payments")
    
    @property
    def is_successful(self) -> bool:
        """Check if payment is successful."""
        return self.status == PaymentStatus.COMPLETED
    
    @property
    def is_refundable(self) -> bool:
        """Check if payment can be refunded."""
        return (
            self.status == PaymentStatus.COMPLETED
            and self.payment_method != PaymentMethod.CASH
        )
    
    @property
    def net_amount(self) -> Decimal:
        """Calculate net amount after refunds."""
        if self.refund_amount:
            return self.amount - self.refund_amount
        return self.amount
    
    def __repr__(self) -> str:
        return f"<Payment(id={self.id}, ref='{self.payment_ref}', amount={self.amount}, status={self.status.value})>"