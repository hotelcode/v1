# path: backend/__init__.py
"""Hotel AI Reception - AI-powered hotel management system."""

__version__ = "0.1.0"
__author__ = "Hotel AI Team"
__email__ = "admin@hotel-ai.com"