# path: backend/api/health.py
from typing import Any, Dict

from fastapi import APIRouter, Depends, Response
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core import get_db, get_redis, get_request_id, get_settings

router = APIRouter()
settings = get_settings()


@router.get("/healthz")
async def health_check(
    response: Response,
    request_id: str = Depends(get_request_id),
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    """Health check endpoint."""
    health_status = {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": "0.1.0",
        "environment": settings.APP_ENV,
        "checks": {
            "database": "unknown",
            "redis": "unknown",
        }
    }
    
    # Check database
    try:
        result = await db.execute(text("SELECT 1"))
        result.scalar()
        health_status["checks"]["database"] = "healthy"
    except Exception as e:
        health_status["checks"]["database"] = "unhealthy"
        health_status["status"] = "degraded"
        if settings.APP_DEBUG:
            health_status["checks"]["database_error"] = str(e)
    
    # Check Redis
    try:
        redis_client = await get_redis()
        await redis_client.ping()
        health_status["checks"]["redis"] = "healthy"
    except Exception as e:
        health_status["checks"]["redis"] = "unhealthy"
        health_status["status"] = "degraded"
        if settings.APP_DEBUG:
            health_status["checks"]["redis_error"] = str(e)
    
    # Set response headers
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Trace-ID"] = request_id
    
    # Set appropriate status code
    if health_status["status"] == "unhealthy":
        response.status_code = 503
    elif health_status["status"] == "degraded":
        response.status_code = 200  # Still return 200 for degraded
    
    return health_status


@router.get("/readyz")
async def readiness_check(
    db: AsyncSession = Depends(get_db),
) -> Dict[str, str]:
    """Readiness check endpoint."""
    # Check if database migrations are applied
    try:
        result = await db.execute(
            text("SELECT 1 FROM alembic_version LIMIT 1")
        )
        result.scalar()
        return {"status": "ready"}
    except Exception:
        return {"status": "not_ready"}


@router.get("/livez")
async def liveness_check() -> Dict[str, str]:
    """Liveness check endpoint."""
    return {"status": "alive"}