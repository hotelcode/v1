# path: backend/api/__init__.py
"""API module for Hotel AI Reception."""

from fastapi import APIRouter

from backend.api.health import router as health_router
from backend.api.v1 import api_v1_router
from backend.api.websocket import router as websocket_router

# Create main API router
api_router = APIRouter()

# Include routers
api_router.include_router(health_router, tags=["Health"])
api_router.include_router(websocket_router, tags=["WebSocket"])
api_router.include_router(api_v1_router, prefix="/api/v1")

__all__ = ["api_router"]