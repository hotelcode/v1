# path: backend/api/v1/bookings.py
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core import (
    PaginationParams,
    get_current_user,
    get_db,
    get_logger,
)
from backend.core.dependencies import rate_limit_default
from backend.core.exceptions import ForbiddenException, NotFoundException
from backend.schemas.booking import (
    BookingCreate,
    BookingResponse,
    BookingUpdate,
    BookingListResponse,
)
from backend.services.booking import BookingService

router = APIRouter()
logger = get_logger(__name__)


@router.post(
    "/",
    response_model=BookingResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_default)],
)
async def create_booking(
    booking_data: BookingCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Create a new booking."""
    booking_service = BookingService(db)
    
    # Guests can only create bookings for themselves
    if current_user["role"] == "guest" and booking_data.guest_id != current_user["id"]:
        raise ForbiddenException("You can only create bookings for yourself")
    
    booking = await booking_service.create_booking(
        booking_data=booking_data,
        created_by_id=current_user["id"]
    )
    
    logger.info(
        "booking_created",
        booking_id=booking.id,
        user_id=current_user["id"]
    )
    
    return BookingResponse.from_orm(booking)


@router.get(
    "/",
    response_model=BookingListResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def list_bookings(
    pagination: PaginationParams = Depends(),
    status: Optional[str] = Query(None, description="Filter by status"),
    room_id: Optional[int] = Query(None, description="Filter by room"),
    guest_id: Optional[int] = Query(None, description="Filter by guest"),
    check_in_date: Optional[str] = Query(None, description="Filter by check-in date"),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingListResponse:
    """List bookings with filters."""
    booking_service = BookingService(db)
    
    # Guests can only see their own bookings
    if current_user["role"] == "guest":
        guest_id = current_user["id"]
    
    bookings, total = await booking_service.list_bookings(
        offset=pagination.offset,
        limit=pagination.limit,
        status=status,
        room_id=room_id,
        guest_id=guest_id,
        check_in_date=check_in_date,
    )
    
    return BookingListResponse(
        items=[BookingResponse.from_orm(b) for b in bookings],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get(
    "/{booking_id}",
    response_model=BookingResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def get_booking(
    booking_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Get booking details."""
    booking_service = BookingService(db)
    booking = await booking_service.get_booking(booking_id)
    
    if not booking:
        raise NotFoundException(f"Booking {booking_id} not found")
    
    # Check permissions
    if current_user["role"] == "guest" and booking.guest_id != current_user["id"]:
        raise ForbiddenException("You don't have access to this booking")
    
    return BookingResponse.from_orm(booking)


@router.patch(
    "/{booking_id}",
    response_model=BookingResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def update_booking(
    booking_id: int,
    booking_update: BookingUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Update booking details."""
    booking_service = BookingService(db)
    booking = await booking_service.get_booking(booking_id)
    
    if not booking:
        raise NotFoundException(f"Booking {booking_id} not found")
    
    # Check permissions
    if current_user["role"] == "guest" and booking.guest_id != current_user["id"]:
        raise ForbiddenException("You don't have access to this booking")
    
    booking = await booking_service.update_booking(
        booking_id=booking_id,
        booking_update=booking_update,
        updated_by_id=current_user["id"]
    )
    
    logger.info(
        "booking_updated",
        booking_id=booking_id,
        user_id=current_user["id"]
    )
    
    return BookingResponse.from_orm(booking)


@router.post(
    "/{booking_id}/cancel",
    response_model=BookingResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def cancel_booking(
    booking_id: int,
    reason: Optional[str] = Query(None, description="Cancellation reason"),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Cancel a booking."""
    booking_service = BookingService(db)
    booking = await booking_service.get_booking(booking_id)
    
    if not booking:
        raise NotFoundException(f"Booking {booking_id} not found")
    
    # Check permissions
    if current_user["role"] == "guest" and booking.guest_id != current_user["id"]:
        raise ForbiddenException("You don't have access to this booking")
    
    booking = await booking_service.cancel_booking(
        booking_id=booking_id,
        reason=reason,
        cancelled_by_id=current_user["id"]
    )
    
    logger.info(
        "booking_cancelled",
        booking_id=booking_id,
        user_id=current_user["id"]
    )
    
    return BookingResponse.from_orm(booking)


@router.post(
    "/{booking_id}/check-in",
    response_model=BookingResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def check_in(
    booking_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Check in a guest."""
    # Only staff can check in guests
    if current_user["role"] == "guest":
        raise ForbiddenException("Only staff can check in guests")
    
    booking_service = BookingService(db)
    booking = await booking_service.check_in(
        booking_id=booking_id,
        checked_in_by_id=current_user["id"]
    )
    
    logger.info(
        "guest_checked_in",
        booking_id=booking_id,
        user_id=current_user["id"]
    )
    
    return BookingResponse.from_orm(booking)


@router.post(
    "/{booking_id}/check-out",
    response_model=BookingResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def check_out(
    booking_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> BookingResponse:
    """Check out a guest."""
    # Only staff can check out guests
    if current_user["role"] == "guest":
        raise ForbiddenException("Only staff can check out guests")
    
    booking_service = BookingService(db)
    booking = await booking_service.check_out(
        booking_id=booking_id,
        checked_out_by_id=current_user["id"]
    )
    
    logger.info(
        "guest_checked_out",
        booking_id=booking_id,
        user_id=current_user["id"]
    )
    
    return BookingResponse.from_orm(booking)