# path: backend/api/v1/rooms.py
from datetime import date
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core import (
    PaginationParams,
    get_current_user,
    get_db,
    get_logger,
)
from backend.core.dependencies import rate_limit_default
from backend.core.exceptions import ForbiddenException, NotFoundException
from backend.core.security import require_manager
from backend.schemas.room import (
    RoomCreate,
    RoomListResponse,
    RoomResponse,
    RoomUpdate,
)
from backend.services.room import RoomService

router = APIRouter()
logger = get_logger(__name__)


@router.post(
    "/",
    response_model=RoomResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_default), Depends(require_manager)],
)
async def create_room(
    room_data: RoomCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> RoomResponse:
    """Create a new room (managers only)."""
    room_service = RoomService(db)
    room = await room_service.create_room(room_data)
    
    logger.info(
        "room_created",
        room_id=room.id,
        room_number=room.room_number,
        user_id=current_user["id"]
    )
    
    return RoomResponse.from_orm(room)


@router.get(
    "/",
    response_model=RoomListResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def list_rooms(
    pagination: PaginationParams = Depends(),
    status: Optional[str] = Query(None, description="Filter by status"),
    room_type: Optional[str] = Query(None, description="Filter by room type"),
    floor: Optional[int] = Query(None, description="Filter by floor"),
    min_price: Optional[float] = Query(None, description="Minimum price"),
    max_price: Optional[float] = Query(None, description="Maximum price"),
    check_in: Optional[date] = Query(None, description="Check-in date for availability"),
    check_out: Optional[date] = Query(None, description="Check-out date for availability"),
    db: AsyncSession = Depends(get_db),
) -> RoomListResponse:
    """List rooms with filters."""
    room_service = RoomService(db)
    
    rooms, total = await room_service.list_rooms(
        offset=pagination.offset,
        limit=pagination.limit,
        status=status,
        room_type=room_type,
        floor=floor,
        min_price=min_price,
        max_price=max_price,
        check_in_date=check_in,
        check_out_date=check_out,
    )
    
    return RoomListResponse(
        items=[RoomResponse.from_orm(room) for room in rooms],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get(
    "/available",
    response_model=List[RoomResponse],
    dependencies=[Depends(rate_limit_default)],
)
async def get_available_rooms(
    check_in: date = Query(..., description="Check-in date"),
    check_out: date = Query(..., description="Check-out date"),
    room_type: Optional[str] = Query(None, description="Filter by room type"),
    max_occupancy: Optional[int] = Query(None, description="Minimum occupancy needed"),
    db: AsyncSession = Depends(get_db),
) -> List[RoomResponse]:
    """Get available rooms for specific dates."""
    room_service = RoomService(db)
    
    rooms = await room_service.get_available_rooms(
        check_in_date=check_in,
        check_out_date=check_out,
        room_type=room_type,
        max_occupancy=max_occupancy,
    )
    
    return [RoomResponse.from_orm(room) for room in rooms]


@router.get(
    "/{room_id}",
    response_model=RoomResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def get_room(
    room_id: int,
    db: AsyncSession = Depends(get_db),
) -> RoomResponse:
    """Get room details."""
    room_service = RoomService(db)
    room = await room_service.get_room(room_id)
    
    if not room:
        raise NotFoundException(f"Room {room_id} not found")
    
    return RoomResponse.from_orm(room)


@router.patch(
    "/{room_id}",
    response_model=RoomResponse,
    dependencies=[Depends(rate_limit_default), Depends(require_manager)],
)
async def update_room(
    room_id: int,
    room_update: RoomUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> RoomResponse:
    """Update room details (managers only)."""
    room_service = RoomService(db)
    room = await room_service.update_room(room_id, room_update)
    
    logger.info(
        "room_updated",
        room_id=room_id,
        user_id=current_user["id"]
    )
    
    return RoomResponse.from_orm(room)


@router.post(
    "/{room_id}/set-price",
    response_model=RoomResponse,
    dependencies=[Depends(rate_limit_default), Depends(require_manager)],
)
async def set_room_price(
    room_id: int,
    price: float = Query(..., description="New room price"),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> RoomResponse:
    """Set room price (managers only)."""
    room_service = RoomService(db)
    room = await room_service.set_room_price(room_id, price)
    
    logger.info(
        "room_price_updated",
        room_id=room_id,
        new_price=price,
        user_id=current_user["id"]
    )
    
    return RoomResponse.from_orm(room)


@router.post(
    "/{room_id}/clean",
    response_model=RoomResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def mark_room_cleaned(
    room_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> RoomResponse:
    """Mark room as cleaned (housekeepers and managers)."""
    if current_user["role"] not in ["housekeeper", "manager", "admin"]:
        raise ForbiddenException("Only housekeeping staff can mark rooms as cleaned")
    
    room_service = RoomService(db)
    room = await room_service.mark_room_cleaned(
        room_id=room_id,
        cleaned_by_id=current_user["id"]
    )
    
    logger.info(
        "room_cleaned",
        room_id=room_id,
        user_id=current_user["id"]
    )
    
    return RoomResponse.from_orm(room)


@router.post(
    "/{room_id}/maintenance",
    response_model=RoomResponse,
    dependencies=[Depends(rate_limit_default), Depends(require_manager)],
)
async def set_room_maintenance(
    room_id: int,
    maintenance: bool = Query(..., description="Set maintenance status"),
    notes: Optional[str] = Query(None, description="Maintenance notes"),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> RoomResponse:
    """Set room maintenance status (managers only)."""
    room_service = RoomService(db)
    room = await room_service.set_maintenance_status(
        room_id=room_id,
        maintenance=maintenance,
        notes=notes,
        updated_by_id=current_user["id"]
    )
    
    logger.info(
        "room_maintenance_updated",
        room_id=room_id,
        maintenance=maintenance,
        user_id=current_user["id"]
    )
    
    return RoomResponse.from_orm(room)