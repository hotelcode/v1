# path: backend/api/v1/__init__.py
"""API v1 module."""

from fastapi import APIRouter

from backend.api.v1.bookings import router as bookings_router
from backend.api.v1.payments import router as payments_router
from backend.api.v1.rooms import router as rooms_router

# Create v1 router
api_v1_router = APIRouter()

# Include routers
api_v1_router.include_router(rooms_router, prefix="/rooms", tags=["Rooms"])
api_v1_router.include_router(bookings_router, prefix="/bookings", tags=["Bookings"])
api_v1_router.include_router(payments_router, prefix="/payments", tags=["Payments"])

__all__ = ["api_v1_router"]