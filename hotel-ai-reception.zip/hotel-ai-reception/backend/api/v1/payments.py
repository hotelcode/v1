# path: backend/api/v1/payments.py
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core import (
    PaginationParams,
    get_current_user,
    get_db,
    get_logger,
)
from backend.core.dependencies import rate_limit_default
from backend.core.exceptions import ForbiddenException, NotFoundException
from backend.core.security import require_manager
from backend.schemas.payment import (
    PaymentCreate,
    PaymentListResponse,
    PaymentResponse,
    RefundRequest,
)
from backend.services.payment import PaymentService

router = APIRouter()
logger = get_logger(__name__)


@router.post(
    "/",
    response_model=PaymentResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(rate_limit_default)],
)
async def create_payment(
    payment_data: PaymentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> PaymentResponse:
    """Create a new payment."""
    payment_service = PaymentService(db)
    
    # Check if user has access to the booking
    from backend.services.booking import BookingService
    booking_service = BookingService(db)
    booking = await booking_service.get_booking(payment_data.booking_id)
    
    if not booking:
        raise NotFoundException("Booking not found")
    
    # Guests can only pay for their own bookings
    if current_user["role"] == "guest" and booking.guest_id != current_user["id"]:
        raise ForbiddenException("You can only pay for your own bookings")
    
    payment = await payment_service.create_payment(
        payment_data=payment_data,
        created_by_id=current_user["id"]
    )
    
    logger.info(
        "payment_created",
        payment_id=payment.id,
        booking_id=payment.booking_id,
        amount=float(payment.amount),
        user_id=current_user["id"]
    )
    
    return PaymentResponse.from_orm(payment)


@router.get(
    "/",
    response_model=PaymentListResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def list_payments(
    pagination: PaginationParams = Depends(),
    booking_id: Optional[int] = Query(None, description="Filter by booking"),
    status: Optional[str] = Query(None, description="Filter by status"),
    payment_method: Optional[str] = Query(None, description="Filter by payment method"),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> PaymentListResponse:
    """List payments with filters."""
    payment_service = PaymentService(db)
    
    # If guest, filter by their bookings
    guest_id = None
    if current_user["role"] == "guest":
        guest_id = current_user["id"]
    
    payments, total = await payment_service.list_payments(
        offset=pagination.offset,
        limit=pagination.limit,
        booking_id=booking_id,
        guest_id=guest_id,
        status=status,
        payment_method=payment_method,
    )
    
    return PaymentListResponse(
        items=[PaymentResponse.from_orm(p) for p in payments],
        total=total,
        page=pagination.page,
        page_size=pagination.page_size,
    )


@router.get(
    "/{payment_id}",
    response_model=PaymentResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def get_payment(
    payment_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> PaymentResponse:
    """Get payment details."""
    payment_service = PaymentService(db)
    payment = await payment_service.get_payment(payment_id)
    
    if not payment:
        raise NotFoundException(f"Payment {payment_id} not found")
    
    # Check permissions
    if current_user["role"] == "guest":
        if payment.booking.guest_id != current_user["id"]:
            raise ForbiddenException("You don't have access to this payment")
    
    return PaymentResponse.from_orm(payment)


@router.post(
    "/{payment_id}/process",
    response_model=PaymentResponse,
    dependencies=[Depends(rate_limit_default)],
)
async def process_payment(
    payment_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> PaymentResponse:
    """Process a pending payment."""
    payment_service = PaymentService(db)
    payment = await payment_service.get_payment(payment_id)
    
    if not payment:
        raise NotFoundException(f"Payment {payment_id} not found")
    
    # Check permissions
    if current_user["role"] == "guest":
        if payment.booking.guest_id != current_user["id"]:
            raise ForbiddenException("You don't have access to this payment")
    
    payment = await payment_service.process_payment(payment_id)
    
    logger.info(
        "payment_processed",
        payment_id=payment_id,
        status=payment.status.value,
        user_id=current_user["id"]
    )
    
    return PaymentResponse.from_orm(payment)


@router.post(
    "/{payment_id}/refund",
    response_model=PaymentResponse,
    dependencies=[Depends(rate_limit_default), Depends(require_manager)],
)
async def refund_payment(
    payment_id: int,
    refund_data: RefundRequest,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> PaymentResponse:
    """Refund a payment (managers only)."""
    payment_service = PaymentService(db)
    
    payment = await payment_service.refund_payment(
        payment_id=payment_id,
        amount=refund_data.amount,
        reason=refund_data.reason,
        refunded_by_id=current_user["id"]
    )
    
    logger.info(
        "payment_refunded",
        payment_id=payment_id,
        refund_amount=float(refund_data.amount),
        user_id=current_user["id"]
    )
    
    return PaymentResponse.from_orm(payment)


@router.get(
    "/booking/{booking_id}",
    response_model=List[PaymentResponse],
    dependencies=[Depends(rate_limit_default)],
)
async def get_booking_payments(
    booking_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(get_current_user),
) -> List[PaymentResponse]:
    """Get all payments for a booking."""
    # Check if user has access to the booking
    from backend.services.booking import BookingService
    booking_service = BookingService(db)
    booking = await booking_service.get_booking(booking_id)
    
    if not booking:
        raise NotFoundException("Booking not found")
    
    # Guests can only see payments for their own bookings
    if current_user["role"] == "guest" and booking.guest_id != current_user["id"]:
        raise ForbiddenException("You don't have access to this booking")
    
    payment_service = PaymentService(db)
    payments = await payment_service.get_booking_payments(booking_id)
    
    return [PaymentResponse.from_orm(p) for p in payments]