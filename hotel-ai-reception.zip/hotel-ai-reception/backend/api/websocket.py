# path: backend/api/websocket.py
import asyncio
import json
from datetime import datetime
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect, status
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core import get_db, get_logger, get_redis, get_settings
from backend.core.exceptions import UnauthorizedException
from backend.core.security import decode_access_token
from backend.schemas.chat import ChatMessage, ChatMessageType
from backend.services.chat import ChatService

router = APIRouter()
settings = get_settings()
logger = get_logger(__name__)


class ConnectionManager:
    """WebSocket connection manager."""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, websocket: WebSocket, client_id: str):
        """Accept new connection."""
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info("websocket_connected", client_id=client_id)
    
    def disconnect(self, client_id: str):
        """Remove connection."""
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            logger.info("websocket_disconnected", client_id=client_id)
    
    async def send_message(self, client_id: str, message: dict):
        """Send message to specific client."""
        if client_id in self.active_connections:
            websocket = self.active_connections[client_id]
            try:
                await websocket.send_json(message)
            except Exception as e:
                logger.error("websocket_send_error", client_id=client_id, error=str(e))
                self.disconnect(client_id)
    
    async def broadcast(self, message: dict, exclude: Optional[List[str]] = None):
        """Broadcast message to all connected clients."""
        exclude = exclude or []
        disconnected = []
        
        for client_id, websocket in self.active_connections.items():
            if client_id not in exclude:
                try:
                    await websocket.send_json(message)
                except Exception:
                    disconnected.append(client_id)
        
        # Clean up disconnected clients
        for client_id in disconnected:
            self.disconnect(client_id)


# Global connection manager
manager = ConnectionManager()


async def get_current_user_ws(websocket: WebSocket) -> Optional[Dict]:
    """Get current user from WebSocket connection."""
    # Try to get token from query params
    token = websocket.query_params.get("token")
    if not token:
        # Try to get from Authorization header
        auth_header = websocket.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
    
    if not token:
        return None
    
    try:
        payload = decode_access_token(token)
        return {
            "id": payload.get("sub"),
            "email": payload.get("email"),
            "role": payload.get("role", "guest"),
        }
    except Exception:
        return None


@router.websocket("/chat")
async def websocket_chat(
    websocket: WebSocket,
    db: AsyncSession = Depends(get_db),
):
    """WebSocket chat endpoint."""
    client_id = None
    user = None
    
    try:
        # Authenticate user
        user = await get_current_user_ws(websocket)
        if not user:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
        
        client_id = f"user_{user['id']}"
        await manager.connect(websocket, client_id)
        
        # Initialize services
        redis_client = await get_redis()
        chat_service = ChatService(db, redis_client)
        
        # Send welcome message
        welcome_message = {
            "type": ChatMessageType.SYSTEM.value,
            "content": "Добро пожаловать в AI-ассистент отеля! Чем могу помочь?",
            "timestamp": datetime.utcnow().isoformat(),
        }
        await manager.send_message(client_id, welcome_message)
        
        # Message processing loop
        while True:
            try:
                # Receive message with timeout
                data = await asyncio.wait_for(
                    websocket.receive_json(),
                    timeout=settings.WS_PING_TIMEOUT
                )
                
                # Validate message
                message = ChatMessage(**data)
                
                # Process message based on type
                if message.type == ChatMessageType.TEXT:
                    # Process text message
                    response = await chat_service.process_text_message(
                        user_id=user["id"],
                        content=message.content,
                        language=message.language
                    )
                    
                    await manager.send_message(client_id, {
                        "type": ChatMessageType.TEXT.value,
                        "content": response,
                        "timestamp": datetime.utcnow().isoformat(),
                    })
                
                elif message.type == ChatMessageType.AUDIO:
                    # Process audio message
                    text = await chat_service.transcribe_audio(message.content)
                    
                    # Send transcription
                    await manager.send_message(client_id, {
                        "type": ChatMessageType.TRANSCRIPTION.value,
                        "content": text,
                        "timestamp": datetime.utcnow().isoformat(),
                    })
                    
                    # Process transcribed text
                    response = await chat_service.process_text_message(
                        user_id=user["id"],
                        content=text,
                        language=message.language
                    )
                    
                    # Send response
                    await manager.send_message(client_id, {
                        "type": ChatMessageType.TEXT.value,
                        "content": response,
                        "timestamp": datetime.utcnow().isoformat(),
                    })
                    
                    # Generate audio response if requested
                    if message.audio_response:
                        audio_url = await chat_service.synthesize_speech(
                            text=response,
                            language=message.language
                        )
                        
                        await manager.send_message(client_id, {
                            "type": ChatMessageType.AUDIO.value,
                            "content": audio_url,
                            "timestamp": datetime.utcnow().isoformat(),
                        })
                
                elif message.type == ChatMessageType.TYPING:
                    # Broadcast typing indicator
                    await manager.broadcast(
                        {
                            "type": ChatMessageType.TYPING.value,
                            "user_id": user["id"],
                            "timestamp": datetime.utcnow().isoformat(),
                        },
                        exclude=[client_id]
                    )
                
            except asyncio.TimeoutError:
                # Send ping
                await websocket.send_json({"type": "ping"})
                
            except WebSocketDisconnect:
                break
                
            except json.JSONDecodeError:
                await manager.send_message(client_id, {
                    "type": ChatMessageType.ERROR.value,
                    "content": "Invalid message format",
                    "timestamp": datetime.utcnow().isoformat(),
                })
                
            except Exception as e:
                logger.error("websocket_error", client_id=client_id, error=str(e))
                await manager.send_message(client_id, {
                    "type": ChatMessageType.ERROR.value,
                    "content": "Произошла ошибка при обработке сообщения",
                    "timestamp": datetime.utcnow().isoformat(),
                })
    
    except WebSocketDisconnect:
        pass
    
    finally:
        if client_id:
            manager.disconnect(client_id)
            logger.info("websocket_closed", client_id=client_id)