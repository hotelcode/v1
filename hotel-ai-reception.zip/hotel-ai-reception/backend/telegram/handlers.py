# path: backend/telegram/handlers.py
from decimal import Decimal
from typing import Optional

from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from backend.core import get_logger, get_settings
from backend.models import Booking, BookingStatus, Room, RoomStatus, User, UserRole
from backend.services.booking import BookingService
from backend.services.payment import PaymentService
from backend.services.room import RoomService

settings = get_settings()
logger = get_logger(__name__)

# Create async engine for handlers
engine = create_async_engine(settings.get_db_url())
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def get_user_by_telegram_id(telegram_id: str) -> Optional[User]:
    """Get user by telegram ID."""
    async with AsyncSessionLocal() as db:
        from sqlalchemy import select
        stmt = select(User).where(User.telegram_id == str(telegram_id))
        result = await db.execute(stmt)
        return result.scalar_one_or_none()


async def check_role(update: Update, context: ContextTypes.DEFAULT_TYPE, required_role: UserRole) -> Optional[User]:
    """Check if user has required role."""
    telegram_id = str(update.effective_user.id)
    user = await get_user_by_telegram_id(telegram_id)
    
    if not user:
        await update.message.reply_text(
            "❌ Вы не зарегистрированы в системе.\n"
            "Обратитесь к администратору."
        )
        return None
    
    allowed_roles = {
        UserRole.GUEST: [UserRole.GUEST, UserRole.HOUSEKEEPER, UserRole.MANAGER, UserRole.ADMIN],
        UserRole.HOUSEKEEPER: [UserRole.HOUSEKEEPER, UserRole.MANAGER, UserRole.ADMIN],
        UserRole.MANAGER: [UserRole.MANAGER, UserRole.ADMIN],
        UserRole.ADMIN: [UserRole.ADMIN],
    }
    
    if user.role not in allowed_roles.get(required_role, []):
        await update.message.reply_text("❌ У вас нет прав для выполнения этой команды.")
        return None
    
    return user


# Command handlers

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command."""
    telegram_id = str(update.effective_user.id)
    user = await get_user_by_telegram_id(telegram_id)
    
    if user:
        role_names = {
            UserRole.GUEST: "Гость",
            UserRole.HOUSEKEEPER: "Горничная",
            UserRole.MANAGER: "Менеджер",
            UserRole.ADMIN: "Администратор",
        }
        
        await update.message.reply_text(
            f"👋 Здравствуйте, {user.full_name}!\n\n"
            f"Ваша роль: {role_names.get(user.role, user.role.value)}\n\n"
            "Доступные команды:\n"
            "/help - Список команд\n"
            "/bookings - Мои бронирования"
        )
    else:
        await update.message.reply_text(
            "👋 Добро пожаловать в Hotel AI Reception!\n\n"
            "Для регистрации обратитесь к администратору.\n"
            "Ваш Telegram ID: " + telegram_id
        )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /help command."""
    user = await get_user_by_telegram_id(str(update.effective_user.id))
    
    if not user:
        await update.message.reply_text("❌ Вы не зарегистрированы в системе.")
        return
    
    commands = {
        UserRole.GUEST: [
            "/bookings - Мои бронирования",
            "/help - Список команд",
        ],
        UserRole.HOUSEKEEPER: [
            "/bookings - Мои бронирования",
            "/cleaned <номер> - Отметить номер как убранный",
            "/cleaning - Список номеров для уборки",
            "/help - Список команд",
        ],
        UserRole.MANAGER: [
            "/bookings - Мои бронирования",
            "/cleaned <номер> - Отметить номер как убранный",
            "/cleaning - Список номеров для уборки",
            "/set_price <номер> <цена> - Установить цену номера",
            "/overbooking - Проверить овербукинг",
            "/refund <бронь> <сумма> - Оформить возврат",
            "/report - Ежедневный отчет",
            "/help - Список команд",
        ],
        UserRole.ADMIN: [
            "Все команды доступны",
        ],
    }
    
    user_commands = commands.get(user.role, [])
    
    await update.message.reply_text(
        "📋 Доступные команды:\n\n" + "\n".join(user_commands)
    )


async def my_bookings(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /bookings command."""
    user = await check_role(update, context, UserRole.GUEST)
    if not user:
        return
    
    async with AsyncSessionLocal() as db:
        booking_service = BookingService(db)
        bookings, _ = await booking_service.list_bookings(
            guest_id=user.id,
            status=BookingStatus.CONFIRMED.value,
            limit=10,
        )
        
        if not bookings:
            await update.message.reply_text("У вас нет активных бронирований.")
            return
        
        response = "📋 Ваши бронирования:\n\n"
        for booking in bookings:
            response += (
                f"📅 Бронь #{booking.booking_ref}\n"
                f"🏨 Номер: {booking.room.room_number}\n"
                f"📆 Заезд: {booking.check_in_date}\n"
                f"📆 Выезд: {booking.check_out_date}\n"
                f"💰 К оплате: {booking.balance_due} KZT\n"
                f"━━━━━━━━━━━━━━━\n"
            )
        
        await update.message.reply_text(response)


async def mark_cleaned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /cleaned command."""
    user = await check_role(update, context, UserRole.HOUSEKEEPER)
    if not user:
        return
    
    if not context.args or len(context.args) != 1:
        await update.message.reply_text(
            "❌ Использование: /cleaned <номер_комнаты>\n"
            "Пример: /cleaned 101"
        )
        return
    
    room_number = context.args[0]
    
    async with AsyncSessionLocal() as db:
        room_service = RoomService(db)
        room = await room_service.get_room_by_number(room_number)
        
        if not room:
            await update.message.reply_text(f"❌ Номер {room_number} не найден.")
            return
        
        if room.status != RoomStatus.CLEANING:
            await update.message.reply_text(f"❌ Номер {room_number} не требует уборки.")
            return
        
        try:
            await room_service.mark_room_cleaned(room.id, user.id)
            await update.message.reply_text(
                f"✅ Номер {room_number} отмечен как убранный.\n"
                f"Статус: Доступен"
            )
            
            logger.info(
                "room_cleaned_telegram",
                room_number=room_number,
                user_id=user.id,
                telegram_id=update.effective_user.id,
            )
            
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")


async def cleaning_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /cleaning command."""
    user = await check_role(update, context, UserRole.HOUSEKEEPER)
    if not user:
        return
    
    async with AsyncSessionLocal() as db:
        room_service = RoomService(db)
        rooms = await room_service.get_rooms_needing_cleaning()
        
        if not rooms:
            await update.message.reply_text("✨ Все номера чистые!")
            return
        
        response = "🧹 Номера для уборки:\n\n"
        for room in rooms:
            response += f"• Номер {room.room_number} (этаж {room.floor})\n"
        
        response += f"\nВсего: {len(rooms)} номеров"
        
        await update.message.reply_text(response)


async def set_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /set_price command."""
    user = await check_role(update, context, UserRole.MANAGER)
    if not user:
        return
    
    if not context.args or len(context.args) != 2:
        await update.message.reply_text(
            "❌ Использование: /set_price <номер_комнаты> <цена>\n"
            "Пример: /set_price 101 25000"
        )
        return
    
    room_number = context.args[0]
    try:
        price = float(context.args[1])
        if price < 0:
            raise ValueError("Цена не может быть отрицательной")
    except ValueError as e:
        await update.message.reply_text(f"❌ Неверная цена: {str(e)}")
        return
    
    async with AsyncSessionLocal() as db:
        room_service = RoomService(db)
        room = await room_service.get_room_by_number(room_number)
        
        if not room:
            await update.message.reply_text(f"❌ Номер {room_number} не найден.")
            return
        
        try:
            await room_service.set_room_price(room.id, price)
            await update.message.reply_text(
                f"✅ Цена номера {room_number} обновлена.\n"
                f"Новая цена: {price:,.0f} KZT"
            )
            
            logger.info(
                "room_price_updated_telegram",
                room_number=room_number,
                new_price=price,
                user_id=user.id,
                telegram_id=update.effective_user.id,
            )
            
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка: {str(e)}")


async def check_overbooking(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /overbooking command."""
    user = await check_role(update, context, UserRole.MANAGER)
    if not user:
        return
    
    # TODO: Implement overbooking check
    await update.message.reply_text("🔄 Функция проверки овербукинга в разработке.")


async def process_refund(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /refund command."""
    user = await check_role(update, context, UserRole.MANAGER)
    if not user:
        return
    
    if not context.args or len(context.args) != 2:
        await update.message.reply_text(
            "❌ Использование: /refund <номер_брони> <сумма>\n"
            "Пример: /refund ABC12345 10000"
        )
        return
    
    booking_ref = context.args[0]
    try:
        amount = Decimal(context.args[1])
        if amount <= 0:
            raise ValueError("Сумма должна быть положительной")
    except ValueError as e:
        await update.message.reply_text(f"❌ Неверная сумма: {str(e)}")
        return
    
    async with AsyncSessionLocal() as db:
        # Find booking
        from sqlalchemy import select
        stmt = select(Booking).where(Booking.booking_ref == booking_ref)
        result = await db.execute(stmt)
        booking = result.scalar_one_or_none()
        
        if not booking:
            await update.message.reply_text(f"❌ Бронирование {booking_ref} не найдено.")
            return
        
        # Get payments
        payment_service = PaymentService(db)
        payments = await payment_service.get_booking_payments(booking.id)
        
        if not payments:
            await update.message.reply_text("❌ Нет платежей для возврата.")
            return
        
        # Find a payment to refund
        payment_to_refund = None
        for payment in payments:
            if payment.is_refundable and payment.net_amount >= amount:
                payment_to_refund = payment
                break
        
        if not payment_to_refund:
            await update.message.reply_text("❌ Нет подходящего платежа для возврата.")
            return
        
        try:
            await payment_service.refund_payment(
                payment_to_refund.id,
                amount,
                f"Возврат через Telegram (менеджер: {user.full_name})",
                user.id,
            )
            
            await update.message.reply_text(
                f"✅ Возврат оформлен:\n"
                f"Бронь: {booking_ref}\n"
                f"Сумма: {amount:,.0f} KZT\n"
                f"Платеж: {payment_to_refund.payment_ref}"
            )
            
            logger.info(
                "refund_processed_telegram",
                booking_ref=booking_ref,
                amount=float(amount),
                user_id=user.id,
                telegram_id=update.effective_user.id,
            )
            
        except Exception as e:
            await update.message.reply_text(f"❌ Ошибка при возврате: {str(e)}")


async def daily_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /report command."""
    user = await check_role(update, context, UserRole.MANAGER)
    if not user:
        return
    
    # Generate report manually
    from backend.tasks.daily import generate_daily_report
    await generate_daily_report()
    
    await update.message.reply_text("📊 Отчет отправлен в канал менеджеров.")


async def unknown_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle unknown commands."""
    await update.message.reply_text(
        "❌ Неизвестная команда.\n"
        "Используйте /help для списка доступных команд."
    )


def setup_handlers(application: Application):
    """Setup command handlers."""
    # Command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("bookings", my_bookings))
    application.add_handler(CommandHandler("cleaned", mark_cleaned))
    application.add_handler(CommandHandler("cleaning", cleaning_list))
    application.add_handler(CommandHandler("set_price", set_price))
    application.add_handler(CommandHandler("overbooking", check_overbooking))
    application.add_handler(CommandHandler("refund", process_refund))
    application.add_handler(CommandHandler("report", daily_report))
    
    # Unknown command handler
    application.add_handler(MessageHandler(filters.COMMAND, unknown_command))
    
    logger.info("telegram_handlers_setup")