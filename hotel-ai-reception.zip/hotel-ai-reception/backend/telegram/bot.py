# path: backend/telegram/bot.py
from typing import Optional

from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters

from backend.core import get_logger, get_settings

settings = get_settings()
logger = get_logger(__name__)


class TelegramBot:
    """Telegram bot wrapper."""
    
    def __init__(self):
        self.token = settings.TELEGRAM_BOT_TOKEN
        self.application: Optional[Application] = None
        self.bot: Optional[Bot] = None
        self._is_running = False
    
    async def start(self):
        """Start the bot."""
        if not self.token:
            logger.warning("telegram_bot_disabled", reason="no token")
            return
        
        if self._is_running:
            return
        
        try:
            # Create application
            self.application = Application.builder().token(self.token).build()
            self.bot = self.application.bot
            
            # Setup handlers
            from backend.telegram.handlers import setup_handlers
            setup_handlers(self.application)
            
            # Initialize and start
            await self.application.initialize()
            await self.application.start()
            self._is_running = True
            
            # Start polling in background
            await self.application.updater.start_polling()
            
            logger.info("telegram_bot_started")
            
        except Exception as e:
            logger.error("telegram_bot_start_failed", error=str(e))
            self._is_running = False
    
    async def stop(self):
        """Stop the bot."""
        if not self._is_running or not self.application:
            return
        
        try:
            await self.application.updater.stop()
            await self.application.stop()
            await self.application.shutdown()
            self._is_running = False
            
            logger.info("telegram_bot_stopped")
            
        except Exception as e:
            logger.error("telegram_bot_stop_failed", error=str(e))
    
    async def send_message(self, chat_id: str, text: str, **kwargs):
        """Send a message to a chat."""
        if not self.bot:
            logger.warning("telegram_bot_not_initialized")
            return
        
        try:
            await self.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode="HTML",
                **kwargs
            )
        except Exception as e:
            logger.error(
                "telegram_send_message_failed",
                chat_id=chat_id,
                error=str(e)
            )
    
    async def send_photo(self, chat_id: str, photo, caption: Optional[str] = None, **kwargs):
        """Send a photo to a chat."""
        if not self.bot:
            logger.warning("telegram_bot_not_initialized")
            return
        
        try:
            await self.bot.send_photo(
                chat_id=chat_id,
                photo=photo,
                caption=caption,
                parse_mode="HTML",
                **kwargs
            )
        except Exception as e:
            logger.error(
                "telegram_send_photo_failed",
                chat_id=chat_id,
                error=str(e)
            )
    
    async def send_document(self, chat_id: str, document, caption: Optional[str] = None, **kwargs):
        """Send a document to a chat."""
        if not self.bot:
            logger.warning("telegram_bot_not_initialized")
            return
        
        try:
            await self.bot.send_document(
                chat_id=chat_id,
                document=document,
                caption=caption,
                parse_mode="HTML",
                **kwargs
            )
        except Exception as e:
            logger.error(
                "telegram_send_document_failed",
                chat_id=chat_id,
                error=str(e)
            )
    
    def is_running(self) -> bool:
        """Check if bot is running."""
        return self._is_running


# Global bot instance
telegram_bot = TelegramBot()