# path: backend/telegram/__init__.py
"""Telegram bot integration for Hotel AI Reception."""

from backend.telegram.bot import TelegramBot, telegram_bot
from backend.telegram.handlers import setup_handlers

__all__ = [
    "TelegramBot",
    "telegram_bot",
    "setup_handlers",
]