# path: backend/tasks/__init__.py
"""Background tasks for Hotel AI Reception."""

from backend.tasks.daily import (
    check_in_reminders,
    check_out_reminders,
    housekeeping_reminders,
    payment_reminders,
)
from backend.tasks.scheduler import scheduler

__all__ = [
    "scheduler",
    "check_in_reminders",
    "check_out_reminders",
    "housekeeping_reminders",
    "payment_reminders",
]