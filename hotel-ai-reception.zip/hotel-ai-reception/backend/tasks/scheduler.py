# path: backend/tasks/scheduler.py
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from backend.core import get_logger, get_settings

settings = get_settings()
logger = get_logger(__name__)

# Create scheduler instance
scheduler = AsyncIOScheduler(
    timezone=settings.APP_TIMEZONE,
    job_defaults={
        "coalesce": True,
        "max_instances": 1,
        "misfire_grace_time": 300,  # 5 minutes
    },
)


def setup_jobs():
    """Setup scheduled jobs."""
    from backend.tasks import daily
    
    # Check-in reminders - daily at 10:00
    scheduler.add_job(
        daily.check_in_reminders,
        CronTrigger(hour=10, minute=0),
        id="check_in_reminders",
        name="Send check-in reminders",
        replace_existing=True,
    )
    
    # Check-out reminders - at configured times
    for reminder_time in settings.CHECKOUT_REMINDER_TIMES:
        hour, minute = map(int, reminder_time.split(":"))
        scheduler.add_job(
            daily.check_out_reminders,
            CronTrigger(hour=hour, minute=minute),
            id=f"check_out_reminder_{reminder_time}",
            name=f"Send check-out reminders at {reminder_time}",
            replace_existing=True,
        )
    
    # Housekeeping reminders - daily at 11:45
    scheduler.add_job(
        daily.housekeeping_reminders,
        CronTrigger(hour=11, minute=45),
        id="housekeeping_reminders",
        name="Send housekeeping reminders",
        replace_existing=True,
    )
    
    # Payment reminders - daily at 09:00
    scheduler.add_job(
        daily.payment_reminders,
        CronTrigger(hour=9, minute=0),
        id="payment_reminders",
        name="Send payment reminders",
        replace_existing=True,
    )
    
    # No-show check - daily at 23:00
    scheduler.add_job(
        daily.check_no_shows,
        CronTrigger(hour=23, minute=0),
        id="check_no_shows",
        name="Check for no-show bookings",
        replace_existing=True,
    )
    
    # Daily reports - daily at 06:00
    scheduler.add_job(
        daily.generate_daily_report,
        CronTrigger(hour=6, minute=0),
        id="daily_report",
        name="Generate daily report",
        replace_existing=True,
    )
    
    logger.info("scheduled_jobs_configured", job_count=len(scheduler.get_jobs()))


# Setup jobs when module is imported
setup_jobs()