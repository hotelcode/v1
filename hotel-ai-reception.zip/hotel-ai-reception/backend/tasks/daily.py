# path: backend/tasks/daily.py
from datetime import date, datetime, timedelta

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from backend.config import NOTIFICATION_CONFIG
from backend.core import get_logger, get_settings
from backend.models import Booking, BookingStatus, Room, RoomStatus
from backend.services.notification import NotificationService
from backend.services.room import RoomService

settings = get_settings()
logger = get_logger(__name__)

# Create async engine for tasks
engine = create_async_engine(settings.get_db_url())
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def check_in_reminders():
    """Send check-in reminders for tomorrow's arrivals."""
    async with AsyncSessionLocal() as db:
        try:
            # Get tomorrow's date
            tomorrow = date.today() + timedelta(days=1)
            
            # Find bookings with check-in tomorrow
            stmt = select(Booking).where(
                and_(
                    Booking.check_in_date == tomorrow,
                    Booking.status == BookingStatus.CONFIRMED,
                )
            )
            result = await db.execute(stmt)
            bookings = result.scalars().all()
            
            # Send reminders
            notification_service = NotificationService(db)
            for booking in bookings:
                await notification_service.send_check_in_reminder(booking)
            
            logger.info(
                "check_in_reminders_sent",
                count=len(bookings),
                date=tomorrow.isoformat(),
            )
            
        except Exception as e:
            logger.error("check_in_reminders_failed", error=str(e))


async def check_out_reminders():
    """Send check-out reminders for today's departures."""
    async with AsyncSessionLocal() as db:
        try:
            # Get today's date
            today = date.today()
            
            # Find bookings with check-out today
            stmt = select(Booking).where(
                and_(
                    Booking.check_out_date == today,
                    Booking.status == BookingStatus.CHECKED_IN,
                )
            )
            result = await db.execute(stmt)
            bookings = result.scalars().all()
            
            # Send reminders
            notification_service = NotificationService(db)
            for booking in bookings:
                await notification_service.send_check_out_reminder(booking)
            
            logger.info(
                "check_out_reminders_sent",
                count=len(bookings),
                date=today.isoformat(),
            )
            
        except Exception as e:
            logger.error("check_out_reminders_failed", error=str(e))


async def housekeeping_reminders():
    """Send housekeeping reminders for rooms needing cleaning."""
    async with AsyncSessionLocal() as db:
        try:
            room_service = RoomService(db)
            rooms = await room_service.get_rooms_needing_cleaning()
            
            if rooms:
                room_numbers = [room.room_number for room in rooms]
                
                notification_service = NotificationService(db)
                await notification_service.notify_housekeeping(room_numbers)
                
                logger.info(
                    "housekeeping_reminders_sent",
                    room_count=len(rooms),
                )
            
        except Exception as e:
            logger.error("housekeeping_reminders_failed", error=str(e))


async def payment_reminders():
    """Send payment reminders for unpaid bookings."""
    async with AsyncSessionLocal() as db:
        try:
            # Configuration
            config = NOTIFICATION_CONFIG["payment_reminder"]
            hours_before = config["hours_before"]
            
            # Calculate cutoff date
            cutoff_date = datetime.now() + timedelta(hours=hours_before)
            
            # Find unpaid bookings
            stmt = select(Booking).where(
                and_(
                    Booking.status.in_([BookingStatus.PENDING, BookingStatus.CONFIRMED]),
                    Booking.balance_due > 0,
                    Booking.check_in_date <= cutoff_date.date(),
                    Booking.requires_prepayment == True,
                )
            )
            result = await db.execute(stmt)
            bookings = result.scalars().all()
            
            # Send reminders
            notification_service = NotificationService(db)
            for booking in bookings:
                await notification_service.send_payment_reminder(booking)
            
            logger.info(
                "payment_reminders_sent",
                count=len(bookings),
            )
            
        except Exception as e:
            logger.error("payment_reminders_failed", error=str(e))


async def check_no_shows():
    """Check for no-show bookings and update their status."""
    async with AsyncSessionLocal() as db:
        try:
            # Get today's date
            today = date.today()
            
            # Find confirmed bookings that should have checked in today
            stmt = select(Booking).where(
                and_(
                    Booking.check_in_date == today,
                    Booking.status == BookingStatus.CONFIRMED,
                    Booking.actual_check_in.is_(None),
                )
            )
            result = await db.execute(stmt)
            bookings = result.scalars().all()
            
            # Mark as no-show
            for booking in bookings:
                booking.status = BookingStatus.NO_SHOW
                
                # Update room status
                room = await db.get(Room, booking.room_id)
                if room and room.status == RoomStatus.RESERVED:
                    room.status = RoomStatus.AVAILABLE
            
            await db.commit()
            
            logger.info(
                "no_shows_processed",
                count=len(bookings),
                date=today.isoformat(),
            )
            
            # Notify manager if there are no-shows
            if bookings:
                notification_service = NotificationService(db)
                await notification_service.notify_manager(
                    "no_shows",
                    {
                        "date": today.isoformat(),
                        "count": len(bookings),
                        "bookings": [b.booking_ref for b in bookings],
                    }
                )
            
        except Exception as e:
            logger.error("check_no_shows_failed", error=str(e))


async def generate_daily_report():
    """Generate and send daily report to managers."""
    async with AsyncSessionLocal() as db:
        try:
            today = date.today()
            yesterday = today - timedelta(days=1)
            
            # Gather statistics
            
            # Today's check-ins
            stmt = select(func.count(Booking.id)).where(
                and_(
                    Booking.check_in_date == today,
                    Booking.status.in_([BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]),
                )
            )
            check_ins_today = await db.scalar(stmt) or 0
            
            # Today's check-outs
            stmt = select(func.count(Booking.id)).where(
                and_(
                    Booking.check_out_date == today,
                    Booking.status.in_([BookingStatus.CHECKED_IN, BookingStatus.CHECKED_OUT]),
                )
            )
            check_outs_today = await db.scalar(stmt) or 0
            
            # Current occupancy
            stmt = select(func.count(Room.id)).where(
                Room.status == RoomStatus.OCCUPIED
            )
            occupied_rooms = await db.scalar(stmt) or 0
            
            # Total active rooms
            stmt = select(func.count(Room.id)).where(
                Room.is_active == True
            )
            total_rooms = await db.scalar(stmt) or 0
            
            # Calculate occupancy rate
            occupancy_rate = (occupied_rooms / total_rooms * 100) if total_rooms > 0 else 0
            
            # Yesterday's revenue
            stmt = select(func.sum(Booking.paid_amount)).where(
                and_(
                    Booking.created_at >= yesterday,
                    Booking.created_at < today,
                )
            )
            revenue_yesterday = await db.scalar(stmt) or 0
            
            # Prepare report
            report = f"""
📊 ЕЖЕДНЕВНЫЙ ОТЧЕТ - {today.isoformat()}

📥 Заезды сегодня: {check_ins_today}
📤 Выезды сегодня: {check_outs_today}

🏨 Загрузка: {occupancy_rate:.1f}% ({occupied_rooms}/{total_rooms})

💰 Выручка за вчера: {revenue_yesterday:,.0f} KZT

--
Автоматический отчет Hotel AI Reception
"""
            
            # Send to manager
            notification_service = NotificationService(db)
            await notification_service.notify_manager(
                "daily_report",
                {
                    "report": report,
                    "date": today.isoformat(),
                    "occupancy_rate": occupancy_rate,
                    "revenue": float(revenue_yesterday),
                }
            )
            
            logger.info(
                "daily_report_generated",
                date=today.isoformat(),
                occupancy_rate=occupancy_rate,
            )
            
        except Exception as e:
            logger.error("generate_daily_report_failed", error=str(e))