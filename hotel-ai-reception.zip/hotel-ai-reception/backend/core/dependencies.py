# path: backend/core/dependencies.py
import uuid
from typing import Optional

import redis.asyncio as redis
from fastapi import Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.config import get_settings
from backend.core.database import get_db
from backend.core.logging import get_request_logger

settings = get_settings()

# Redis connection pool
redis_pool: Optional[redis.ConnectionPool] = None


async def get_redis() -> redis.Redis:
    """Get Redis connection."""
    global redis_pool
    
    if redis_pool is None:
        redis_pool = redis.ConnectionPool.from_url(
            settings.get_redis_url(),
            max_connections=50,
            decode_responses=True
        )
    
    return redis.Redis(connection_pool=redis_pool)


async def get_request_id(
    x_request_id: Optional[str] = Header(None),
    x_correlation_id: Optional[str] = Header(None),
) -> str:
    """Get or generate request ID."""
    return x_request_id or x_correlation_id or str(uuid.uuid4())


async def get_logger(
    request: Request,
    request_id: str = Depends(get_request_id),
):
    """Get logger with request context."""
    user_id = getattr(request.state, "user_id", None)
    return get_request_logger(request_id, user_id)


class PaginationParams:
    """Pagination parameters."""
    
    def __init__(
        self,
        page: int = 1,
        page_size: int = settings.DEFAULT_PAGE_SIZE,
    ):
        self.page = max(1, page)
        self.page_size = min(page_size, settings.MAX_PAGE_SIZE)
        self.offset = (self.page - 1) * self.page_size
        self.limit = self.page_size


class DatabaseSession:
    """Database session dependency with transaction support."""
    
    def __init__(self, db: AsyncSession = Depends(get_db)):
        self.db = db
    
    async def __aenter__(self):
        return self.db
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            await self.db.rollback()
        else:
            await self.db.commit()
        await self.db.close()


async def get_db_session() -> DatabaseSession:
    """Get database session with transaction support."""
    return DatabaseSession()


class RateLimiter:
    """Rate limiter dependency."""
    
    def __init__(self, max_requests: int = 60, window: int = 60):
        self.max_requests = max_requests
        self.window = window
    
    async def __call__(
        self,
        request: Request,
        redis_client: redis.Redis = Depends(get_redis),
    ) -> bool:
        """Check rate limit."""
        if not settings.RATE_LIMIT_ENABLED:
            return True
        
        # Get client IP
        client_ip = request.client.host
        key = f"rate_limit:{client_ip}:{request.url.path}"
        
        # Check current count
        current = await redis_client.incr(key)
        if current == 1:
            await redis_client.expire(key, self.window)
        
        if current > self.max_requests:
            from backend.core.exceptions import RateLimitException
            raise RateLimitException(
                detail=f"Rate limit exceeded: {self.max_requests} requests per {self.window} seconds",
                retry_after=self.window
            )
        
        return True


# Pre-configured rate limiters
rate_limit_default = RateLimiter(max_requests=settings.RATE_LIMIT_PER_MINUTE, window=60)
rate_limit_strict = RateLimiter(max_requests=10, window=60)
rate_limit_auth = RateLimiter(max_requests=5, window=300)  # 5 attempts per 5 minutes