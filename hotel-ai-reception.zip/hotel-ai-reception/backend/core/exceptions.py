# path: backend/core/exceptions.py
from typing import Any, Dict, Optional

from fastapi import HTTPException, status


class BaseAPIException(HTTPException):
    """Base exception for API errors."""

    def __init__(
        self,
        status_code: int,
        detail: str,
        headers: Optional[Dict[str, Any]] = None,
        error_code: Optional[str] = None,
    ):
        super().__init__(status_code=status_code, detail=detail, headers=headers)
        self.error_code = error_code or self.__class__.__name__


class BadRequestException(BaseAPIException):
    """Bad request exception."""

    def __init__(self, detail: str = "Bad request", **kwargs):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=detail,
            **kwargs
        )


class UnauthorizedException(BaseAPIException):
    """Unauthorized exception."""

    def __init__(self, detail: str = "Unauthorized", **kwargs):
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail,
            headers={"WWW-Authenticate": "Bearer"},
            **kwargs
        )


class ForbiddenException(BaseAPIException):
    """Forbidden exception."""

    def __init__(self, detail: str = "Forbidden", **kwargs):
        super().__init__(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=detail,
            **kwargs
        )


class NotFoundException(BaseAPIException):
    """Not found exception."""

    def __init__(self, detail: str = "Not found", **kwargs):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=detail,
            **kwargs
        )


class ConflictException(BaseAPIException):
    """Conflict exception."""

    def __init__(self, detail: str = "Conflict", **kwargs):
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=detail,
            **kwargs
        )


class ValidationException(BaseAPIException):
    """Validation exception."""

    def __init__(self, detail: str = "Validation error", **kwargs):
        super().__init__(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=detail,
            **kwargs
        )


class RateLimitException(BaseAPIException):
    """Rate limit exceeded exception."""

    def __init__(self, detail: str = "Rate limit exceeded", retry_after: int = 60, **kwargs):
        super().__init__(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=detail,
            headers={"Retry-After": str(retry_after)},
            **kwargs
        )


class InternalServerException(BaseAPIException):
    """Internal server error exception."""

    def __init__(self, detail: str = "Internal server error", **kwargs):
        super().__init__(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=detail,
            **kwargs
        )


class ServiceUnavailableException(BaseAPIException):
    """Service unavailable exception."""

    def __init__(self, detail: str = "Service unavailable", **kwargs):
        super().__init__(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=detail,
            **kwargs
        )


# Business logic exceptions
class BookingException(BaseAPIException):
    """Base booking exception."""
    pass


class RoomNotAvailableException(BookingException):
    """Room not available exception."""

    def __init__(self, room_id: str, **kwargs):
        super().__init__(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Room {room_id} is not available for the selected dates",
            error_code="ROOM_NOT_AVAILABLE",
            **kwargs
        )


class InvalidBookingDatesException(BookingException):
    """Invalid booking dates exception."""

    def __init__(self, detail: str = "Invalid booking dates", **kwargs):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=detail,
            error_code="INVALID_BOOKING_DATES",
            **kwargs
        )


class BookingNotFoundException(BookingException):
    """Booking not found exception."""

    def __init__(self, booking_id: str, **kwargs):
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Booking {booking_id} not found",
            error_code="BOOKING_NOT_FOUND",
            **kwargs
        )


class PaymentException(BaseAPIException):
    """Base payment exception."""
    pass


class PaymentFailedException(PaymentException):
    """Payment failed exception."""

    def __init__(self, detail: str = "Payment failed", **kwargs):
        super().__init__(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=detail,
            error_code="PAYMENT_FAILED",
            **kwargs
        )


class RefundNotAllowedException(PaymentException):
    """Refund not allowed exception."""

    def __init__(self, detail: str = "Refund not allowed", **kwargs):
        super().__init__(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=detail,
            error_code="REFUND_NOT_ALLOWED",
            **kwargs
        )