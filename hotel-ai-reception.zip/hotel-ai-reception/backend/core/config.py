# path: backend/core/config.py
from functools import lru_cache
from typing import Any, Dict, Optional

from pydantic import Field, PostgresDsn, RedisDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )

    # Application
    APP_NAME: str = "hotel-ai-reception"
    APP_ENV: str = Field(default="development", pattern="^(development|staging|production)$")
    APP_DEBUG: bool = False
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000
    APP_TIMEZONE: str = "Asia/Almaty"

    # Security
    SECRET_KEY: str
    JWT_SECRET_KEY: str
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_MINUTES: int = 1440

    # Database
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "hotel_ai"
    POSTGRES_USER: str = "hotel_user"
    POSTGRES_PASSWORD: str
    DATABASE_URL: Optional[PostgresDsn] = None

    @field_validator("DATABASE_URL", mode="before")
    @classmethod
    def assemble_db_connection(cls, v: Optional[str], info: Any) -> Any:
        if isinstance(v, str):
            return v
        return PostgresDsn.build(
            scheme="postgresql+asyncpg",
            username=info.data.get("POSTGRES_USER"),
            password=info.data.get("POSTGRES_PASSWORD"),
            host=info.data.get("POSTGRES_HOST"),
            port=info.data.get("POSTGRES_PORT"),
            path=info.data.get("POSTGRES_DB"),
        )

    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: str = ""
    REDIS_URL: Optional[RedisDsn] = None

    @field_validator("REDIS_URL", mode="before")
    @classmethod
    def assemble_redis_connection(cls, v: Optional[str], info: Any) -> Any:
        if isinstance(v, str):
            return v
        password = info.data.get("REDIS_PASSWORD")
        if password:
            return RedisDsn.build(
                scheme="redis",
                username="",
                password=password,
                host=info.data.get("REDIS_HOST"),
                port=info.data.get("REDIS_PORT"),
                path=str(info.data.get("REDIS_DB")),
            )
        return RedisDsn.build(
            scheme="redis",
            host=info.data.get("REDIS_HOST"),
            port=info.data.get("REDIS_PORT"),
            path=str(info.data.get("REDIS_DB")),
        )

    # Telegram Bot
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_MANAGER_CHAT_ID: Optional[str] = None
    TELEGRAM_CLEANER_CHAT_ID: Optional[str] = None

    # Email
    SMTP_HOST: str = "localhost"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = "noreply@hotel-ai.com"
    SMTP_FROM_NAME: str = "Hotel AI Reception"
    SMTP_TLS: bool = True
    SMTP_SSL: bool = False

    # AI Services
    WHISPER_SERVICE_URL: str = "http://whisper-stub:8000"
    COQUI_SERVICE_URL: str = "http://coqui-stub:8001"

    # Observability
    OTEL_EXPORTER_OTLP_ENDPOINT: str = "http://otel-collector:4317"
    OTEL_SERVICE_NAME: str = "hotel-ai-reception"
    OTEL_TRACES_EXPORTER: str = "otlp"
    OTEL_METRICS_EXPORTER: str = "otlp"
    PROMETHEUS_MULTIPROC_DIR: str = "/tmp/prometheus"

    # Monitoring URLs
    GRAFANA_URL: str = "http://grafana:3000"
    LOKI_URL: str = "http://loki:3100"
    TEMPO_URL: str = "http://tempo:3200"

    # External Services
    SENTRY_DSN: Optional[str] = None
    PAYMENT_GATEWAY_API_KEY: Optional[str] = None
    SMS_GATEWAY_API_KEY: Optional[str] = None

    # Feature Flags
    OFFLOAD_HEAVY: int = 0
    ENABLE_TELEGRAM_BOT: bool = True
    ENABLE_EMAIL_NOTIFICATIONS: bool = True
    ENABLE_SMS_NOTIFICATIONS: bool = False

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PER_MINUTE: int = 60
    RATE_LIMIT_BURST: int = 10

    # CORS
    CORS_ORIGINS: list[str] = ["*"]
    CORS_CREDENTIALS: bool = True
    CORS_METHODS: list[str] = ["*"]
    CORS_HEADERS: list[str] = ["*"]

    # Pagination
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100

    # WebSocket
    WS_MESSAGE_QUEUE_SIZE: int = 100
    WS_PING_INTERVAL: int = 30
    WS_PING_TIMEOUT: int = 10

    # Business Rules
    PREPAYMENT_MIN_DAYS_FOR_50: int = 3
    PREPAYMENT_PERCENT_SHORT: int = 100
    PREPAYMENT_PERCENT_LONG: int = 50
    
    REFUND_MORE_72H: float = 1.0
    REFUND_24_72H: float = 0.5
    REFUND_LESS_24H: float = 0.0
    REFUND_NO_SHOW: float = 0.0
    
    CHECKOUT_REMINDER_TIMES: list[str] = ["11:45", "12:00"]
    CHECKOUT_FREE_EXTENSION_HOURS: int = 1

    @property
    def is_production(self) -> bool:
        """Check if running in production."""
        return self.APP_ENV == "production"

    @property
    def is_development(self) -> bool:
        """Check if running in development."""
        return self.APP_ENV == "development"

    def get_db_url(self, sync: bool = False) -> str:
        """Get database URL."""
        if sync:
            return str(self.DATABASE_URL).replace("+asyncpg", "")
        return str(self.DATABASE_URL)

    def get_redis_url(self) -> str:
        """Get Redis URL."""
        return str(self.REDIS_URL)


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()