# path: backend/core/logging.py
import logging
import sys
from typing import Any, Dict

import structlog
from structlog.processors import CallsiteParameter, CallsiteParameterAdder

from backend.core.config import get_settings

settings = get_settings()


def setup_logging() -> None:
    """Configure structured logging."""
    
    # Configure standard logging
    logging.basicConfig(
        format="%(message)s",
        stream=sys.stdout,
        level=logging.DEBUG if settings.APP_DEBUG else logging.INFO,
    )

    # Configure structlog
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            CallsiteParameterAdder(
                parameters=[
                    CallsiteParameter.FILENAME,
                    CallsiteParameter.FUNC_NAME,
                    CallsiteParameter.LINENO,
                ]
            ),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> structlog.BoundLogger:
    """Get a structured logger instance."""
    return structlog.get_logger(name)


# Logger instance
logger = get_logger(__name__)


class LoggerAdapter:
    """Adapter to add context to logs."""

    def __init__(self, logger: structlog.BoundLogger, extra: Dict[str, Any]):
        self.logger = logger
        self.extra = extra

    def bind(self, **kwargs: Any) -> "LoggerAdapter":
        """Bind additional context."""
        return LoggerAdapter(self.logger, {**self.extra, **kwargs})

    def info(self, event: str, **kwargs: Any) -> None:
        """Log info message."""
        self.logger.info(event, **self.extra, **kwargs)

    def error(self, event: str, **kwargs: Any) -> None:
        """Log error message."""
        self.logger.error(event, **self.extra, **kwargs)

    def warning(self, event: str, **kwargs: Any) -> None:
        """Log warning message."""
        self.logger.warning(event, **self.extra, **kwargs)

    def debug(self, event: str, **kwargs: Any) -> None:
        """Log debug message."""
        self.logger.debug(event, **self.extra, **kwargs)


def get_request_logger(request_id: str, user_id: str | None = None) -> LoggerAdapter:
    """Get logger with request context."""
    context = {
        "request_id": request_id,
        "service": settings.OTEL_SERVICE_NAME,
        "environment": settings.APP_ENV,
    }
    if user_id:
        context["user_id"] = user_id
    
    return LoggerAdapter(logger, context)