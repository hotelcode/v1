# path: backend/core/__init__.py
"""Core functionality for Hotel AI Reception."""

from backend.core.config import Settings, get_settings
from backend.core.database import Base, get_db
from backend.core.dependencies import (
    PaginationParams,
    get_logger,
    get_redis,
    get_request_id,
)
from backend.core.exceptions import (
    BadRequestException,
    ConflictException,
    ForbiddenException,
    InternalServerException,
    NotFoundException,
    RateLimitException,
    ServiceUnavailableException,
    UnauthorizedException,
    ValidationException,
)
from backend.core.logging import setup_logging
from backend.core.security import (
    create_access_token,
    get_current_user,
    get_password_hash,
    verify_password,
)

__all__ = [
    # Config
    "Settings",
    "get_settings",
    # Database
    "Base",
    "get_db",
    # Dependencies
    "get_redis",
    "get_request_id",
    "get_logger",
    "PaginationParams",
    # Exceptions
    "BadRequestException",
    "UnauthorizedException",
    "ForbiddenException",
    "NotFoundException",
    "ConflictException",
    "ValidationException",
    "RateLimitException",
    "InternalServerException",
    "ServiceUnavailableException",
    # Logging
    "setup_logging",
    # Security
    "verify_password",
    "get_password_hash",
    "create_access_token",
    "get_current_user",
]