# path: backend/utils/metrics.py
from prometheus_client import Counter, Gauge, Histogram

# HTTP metrics
http_request_duration = Histogram(
    "http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "endpoint", "status_code"],
)

http_requests_total = Counter(
    "http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status_code"],
)

# WebSocket metrics
ws_connections_gauge = Gauge(
    "websocket_connections_active",
    "Number of active WebSocket connections",
)

ws_messages_total = Counter(
    "websocket_messages_total",
    "Total WebSocket messages",
    ["direction", "message_type"],
)

# Business metrics
booking_counter = Counter(
    "bookings_total",
    "Total number of bookings",
    ["status", "source"],
)

payment_counter = Counter(
    "payments_total",
    "Total number of payments",
    ["status", "method"],
)

payment_amount_histogram = Histogram(
    "payment_amount_kzt",
    "Payment amounts in KZT",
    ["method"],
    buckets=[1000, 5000, 10000, 25000, 50000, 100000, 250000, 500000],
)

room_occupancy_gauge = Gauge(
    "room_occupancy_percent",
    "Room occupancy percentage",
)

# Cache metrics
cache_hits = Counter(
    "cache_hits_total",
    "Total cache hits",
    ["cache_name"],
)

cache_misses = Counter(
    "cache_misses_total",
    "Total cache misses",
    ["cache_name"],
)

# Database metrics
db_query_duration = Histogram(
    "database_query_duration_seconds",
    "Database query duration in seconds",
    ["query_type", "table"],
)

db_connection_pool_size = Gauge(
    "database_connection_pool_size",
    "Database connection pool size",
    ["pool_name", "state"],
)

# Task metrics
task_duration = Histogram(
    "task_duration_seconds",
    "Background task duration in seconds",
    ["task_name"],
)

task_failures = Counter(
    "task_failures_total",
    "Total task failures",
    ["task_name"],
)

# AI service metrics
ai_request_duration = Histogram(
    "ai_request_duration_seconds",
    "AI service request duration in seconds",
    ["service", "operation"],
)

ai_request_failures = Counter(
    "ai_request_failures_total",
    "Total AI service request failures",
    ["service", "operation"],
)

# Notification metrics
notification_sent = Counter(
    "notifications_sent_total",
    "Total notifications sent",
    ["channel", "type"],
)

notification_failures = Counter(
    "notification_failures_total",
    "Total notification failures",
    ["channel", "type"],
)


def record_booking(status: str, source: str = "unknown"):
    """Record a booking metric."""
    booking_counter.labels(status=status, source=source).inc()


def record_payment(status: str, method: str, amount: float):
    """Record a payment metric."""
    payment_counter.labels(status=status, method=method).inc()
    payment_amount_histogram.labels(method=method).observe(amount)


def update_room_occupancy(percent: float):
    """Update room occupancy gauge."""
    room_occupancy_gauge.set(percent)


def record_cache_hit(cache_name: str):
    """Record a cache hit."""
    cache_hits.labels(cache_name=cache_name).inc()


def record_cache_miss(cache_name: str):
    """Record a cache miss."""
    cache_misses.labels(cache_name=cache_name).inc()


def record_notification(channel: str, notification_type: str, success: bool = True):
    """Record a notification metric."""
    if success:
        notification_sent.labels(channel=channel, type=notification_type).inc()
    else:
        notification_failures.labels(channel=channel, type=notification_type).inc()