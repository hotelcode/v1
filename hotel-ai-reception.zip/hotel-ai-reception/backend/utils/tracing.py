# path: backend/utils/tracing.py
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.instrumentation.asyncpg import AsyncPGInstrumentor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.redis import RedisInstrumentor
from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from backend.core import get_logger, get_settings

settings = get_settings()
logger = get_logger(__name__)


def setup_tracing():
    """Setup OpenTelemetry tracing."""
    if settings.is_development:
        logger.info("tracing_disabled", reason="development environment")
        return
    
    try:
        # Create resource
        resource = Resource.create({
            "service.name": settings.OTEL_SERVICE_NAME,
            "service.version": "0.1.0",
            "service.environment": settings.APP_ENV,
        })
        
        # Create tracer provider
        provider = TracerProvider(resource=resource)
        
        # Create OTLP exporter
        otlp_exporter = OTLPSpanExporter(
            endpoint=settings.OTEL_EXPORTER_OTLP_ENDPOINT,
            insecure=True,
        )
        
        # Add span processor
        span_processor = BatchSpanProcessor(otlp_exporter)
        provider.add_span_processor(span_processor)
        
        # Set tracer provider
        trace.set_tracer_provider(provider)
        
        # Instrument libraries
        FastAPIInstrumentor.instrument(
            excluded_urls="/healthz,/readyz,/livez,/metrics"
        )
        
        SQLAlchemyInstrumentor().instrument(
            engine=None,  # Will instrument all engines
            skip_dep_check=True,
        )
        
        AsyncPGInstrumentor().instrument(skip_dep_check=True)
        RedisInstrumentor().instrument(skip_dep_check=True)
        HTTPXClientInstrumentor().instrument(skip_dep_check=True)
        
        logger.info("tracing_setup_complete")
        
    except Exception as e:
        logger.error("tracing_setup_failed", error=str(e))


def get_tracer(name: str) -> trace.Tracer:
    """Get a tracer instance."""
    return trace.get_tracer(name)