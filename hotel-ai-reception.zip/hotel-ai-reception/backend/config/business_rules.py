# path: backend/config/business_rules.py
from datetime import timedelta
from decimal import Decimal
from typing import Dict, List

# Prepayment rules
PREPAYMENT_RULES = {
    "min_days_for_50%": 3,  # Minimum days before check-in for 50% prepayment
    "percent_short": 100,   # Prepayment percentage for bookings < min_days
    "percent_long": 50,     # Prepayment percentage for bookings >= min_days
}

# Refund policy based on cancellation time
REFUND_POLICY = {
    "more_72h": 1.0,    # 100% refund if cancelled > 72 hours before check-in
    "24_72h": 0.5,      # 50% refund if cancelled 24-72 hours before check-in
    "less_24h": 0.0,    # No refund if cancelled < 24 hours before check-in
    "no_show": 0.0,     # No refund for no-show
}

# Check-out configuration
CHECKOUT = {
    "reminders": ["11:45", "12:00"],  # Reminder times in HH:MM format
    "free_extension": timedelta(hours=1),  # Free extension period
    "standard_time": "12:00",  # Standard check-out time
}

# Check-in configuration
CHECKIN = {
    "standard_time": "14:00",  # Standard check-in time
    "early_fee_percent": 20,   # Early check-in fee as percentage of room rate
    "min_early_hours": 2,      # Minimum hours for early check-in
}

# Room status configurations
ROOM_STATUS = {
    "available": "available",
    "occupied": "occupied",
    "maintenance": "maintenance",
    "cleaning": "cleaning",
    "reserved": "reserved",
}

# Booking status configurations
BOOKING_STATUS = {
    "pending": "pending",
    "confirmed": "confirmed",
    "checked_in": "checked_in",
    "checked_out": "checked_out",
    "cancelled": "cancelled",
    "no_show": "no_show",
}

# Payment configurations
PAYMENT_CONFIG = {
    "currencies": ["KZT", "USD", "EUR"],
    "default_currency": "KZT",
    "payment_methods": ["cash", "card", "bank_transfer", "online"],
    "online_payment_timeout": timedelta(hours=2),  # Timeout for online payments
}

# Pricing rules
PRICING_RULES = {
    "weekend_multiplier": 1.2,  # 20% increase for weekends
    "holiday_multiplier": 1.5,  # 50% increase for holidays
    "last_minute_discount": 0.15,  # 15% discount for last-minute bookings
    "last_minute_hours": 24,  # Hours before check-in for last-minute discount
    "long_stay_discount": {
        "7_days": 0.05,   # 5% discount for 7+ days
        "14_days": 0.10,  # 10% discount for 14+ days
        "30_days": 0.20,  # 20% discount for 30+ days
    },
}

# Notification settings
NOTIFICATION_CONFIG = {
    "booking_confirmation": {
        "email": True,
        "sms": True,
        "telegram": True,
    },
    "check_in_reminder": {
        "hours_before": 24,
        "email": True,
        "sms": False,
        "telegram": True,
    },
    "check_out_reminder": {
        "minutes_before": [60, 15],  # Send reminders 60 and 15 minutes before
        "telegram": True,
    },
    "payment_reminder": {
        "hours_before": 48,
        "email": True,
        "telegram": True,
    },
}

# Housekeeping configuration
HOUSEKEEPING_CONFIG = {
    "cleaning_time_minutes": {
        "standard": 30,
        "suite": 45,
        "vip": 60,
    },
    "inspection_required": True,
    "daily_cleaning_start": "09:00",
    "daily_cleaning_end": "17:00",
}

# Guest preferences
GUEST_PREFERENCES = {
    "smoking": ["non_smoking", "smoking"],
    "floor": ["low", "high", "any"],
    "bed_type": ["single", "double", "twin", "king"],
    "view": ["city", "garden", "pool", "any"],
    "amenities": [
        "wifi",
        "minibar",
        "safe",
        "balcony",
        "bathtub",
        "kitchen",
        "workspace",
    ],
}

# AI Assistant configuration
AI_ASSISTANT_CONFIG = {
    "languages": ["ru", "en", "kk"],
    "default_language": "ru",
    "max_audio_duration_seconds": 60,
    "max_message_length": 1000,
    "typing_indicator_delay_ms": 500,
    "response_timeout_seconds": 30,
}

# Rate limiting rules per role
RATE_LIMITS = {
    "guest": {
        "chat_messages_per_minute": 10,
        "api_calls_per_minute": 60,
    },
    "housekeeper": {
        "chat_messages_per_minute": 20,
        "api_calls_per_minute": 120,
    },
    "manager": {
        "chat_messages_per_minute": 50,
        "api_calls_per_minute": 300,
    },
}

# Commission and fees
FEES_CONFIG = {
    "online_payment_fee_percent": 2.5,
    "cancellation_fee_fixed": Decimal("5000"),  # Fixed cancellation fee in KZT
    "late_checkout_hourly_rate_percent": 10,  # % of daily rate per hour
}


def calculate_prepayment_amount(total_amount: Decimal, days_before_checkin: int) -> Decimal:
    """Calculate prepayment amount based on business rules."""
    if days_before_checkin < PREPAYMENT_RULES["min_days_for_50%"]:
        percent = PREPAYMENT_RULES["percent_short"]
    else:
        percent = PREPAYMENT_RULES["percent_long"]
    
    return total_amount * Decimal(percent) / 100


def calculate_refund_amount(paid_amount: Decimal, hours_before_checkin: float) -> Decimal:
    """Calculate refund amount based on cancellation policy."""
    if hours_before_checkin > 72:
        refund_rate = REFUND_POLICY["more_72h"]
    elif 24 <= hours_before_checkin <= 72:
        refund_rate = REFUND_POLICY["24_72h"]
    else:
        refund_rate = REFUND_POLICY["less_24h"]
    
    refund = paid_amount * Decimal(str(refund_rate))
    
    # Subtract cancellation fee
    if refund > 0:
        refund = max(refund - FEES_CONFIG["cancellation_fee_fixed"], Decimal("0"))
    
    return refund