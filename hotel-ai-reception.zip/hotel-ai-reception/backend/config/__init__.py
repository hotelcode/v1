# path: backend/config/__init__.py
"""Configuration module for Hotel AI Reception."""

from backend.config.business_rules import (
    AI_ASSISTANT_CONFIG,
    BOOKING_STATUS,
    CHECKIN,
    CHECKOUT,
    FEES_CONFIG,
    GUEST_PREFERENCES,
    HOUSEKEEPING_CONFIG,
    NOTIFICATION_CONFIG,
    PAYMENT_CONFIG,
    PREPAYMENT_RULES,
    PRICING_RULES,
    RATE_LIMITS,
    REFUND_POLICY,
    ROOM_STATUS,
    calculate_prepayment_amount,
    calculate_refund_amount,
)

__all__ = [
    # Rules and configurations
    "PREPAYMENT_RULES",
    "REFUND_POLICY",
    "CHECKOUT",
    "CHECKIN",
    "ROOM_STATUS",
    "BOOKING_STATUS",
    "PAYMENT_CONFIG",
    "PRICING_RULES",
    "NOTIFICATION_CONFIG",
    "HOUSEKEEPING_CONFIG",
    "GUEST_PREFERENCES",
    "AI_ASSISTANT_CONFIG",
    "RATE_LIMITS",
    "FEES_CONFIG",
    # Functions
    "calculate_prepayment_amount",
    "calculate_refund_amount",
]