# path: tests/conftest.py
import asyncio
from typing import AsyncGenerator, Generator

import pytest
import pytest_asyncio
from faker import Faker
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from backend.core.config import get_settings
from backend.core.database import Base, get_db
from backend.main import app
from backend.models import Room, RoomStatus, RoomType, User, UserRole

# Test database URL
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

# Create test engine
test_engine = create_async_engine(TEST_DATABASE_URL, echo=False)
TestSessionLocal = async_sessionmaker(test_engine, expire_on_commit=False)

# Faker instance
fake = Faker()


@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Create event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def test_db() -> AsyncGenerator[AsyncSession, None]:
    """Create test database session."""
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    async with TestSessionLocal() as session:
        yield session
    
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)


@pytest_asyncio.fixture
async def client(test_db: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """Create test client with overridden database."""
    
    async def override_get_db():
        yield test_db
    
    app.dependency_overrides[get_db] = override_get_db
    
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac
    
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def test_user(test_db: AsyncSession) -> User:
    """Create test user."""
    from backend.core.security import get_password_hash
    
    user = User(
        email=fake.email(),
        phone=fake.phone_number()[:20],
        password_hash=get_password_hash("testpassword"),
        first_name=fake.first_name(),
        last_name=fake.last_name(),
        role=UserRole.GUEST,
        is_active=True,
        is_verified=True,
    )
    
    test_db.add(user)
    await test_db.commit()
    await test_db.refresh(user)
    
    return user


@pytest_asyncio.fixture
async def test_manager(test_db: AsyncSession) -> User:
    """Create test manager user."""
    from backend.core.security import get_password_hash
    
    manager = User(
        email="manager@hotel.com",
        password_hash=get_password_hash("managerpass"),
        first_name="Test",
        last_name="Manager",
        role=UserRole.MANAGER,
        is_active=True,
        is_verified=True,
    )
    
    test_db.add(manager)
    await test_db.commit()
    await test_db.refresh(manager)
    
    return manager


@pytest_asyncio.fixture
async def test_room(test_db: AsyncSession) -> Room:
    """Create test room."""
    room = Room(
        room_number="101",
        floor=1,
        room_type=RoomType.DOUBLE,
        status=RoomStatus.AVAILABLE,
        max_occupancy=2,
        single_beds=0,
        double_beds=1,
        base_price=25000,
        is_active=True,
    )
    
    test_db.add(room)
    await test_db.commit()
    await test_db.refresh(room)
    
    return room


@pytest_asyncio.fixture
async def auth_headers(test_user: User) -> dict:
    """Create authentication headers for test user."""
    from backend.core.security import create_access_token
    
    token = create_access_token({"sub": str(test_user.id), "email": test_user.email})
    return {"Authorization": f"Bearer {token}"}


@pytest_asyncio.fixture
async def manager_auth_headers(test_manager: User) -> dict:
    """Create authentication headers for test manager."""
    from backend.core.security import create_access_token
    
    token = create_access_token({"sub": str(test_manager.id), "email": test_manager.email, "role": "manager"})
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def mock_settings():
    """Mock settings for tests."""
    settings = get_settings()
    settings.OFFLOAD_HEAVY = 1  # Disable heavy services in tests
    settings.ENABLE_TELEGRAM_BOT = False
    settings.ENABLE_EMAIL_NOTIFICATIONS = False
    settings.ENABLE_SMS_NOTIFICATIONS = False
    return settings