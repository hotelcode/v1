# path: tests/test_services/test_booking.py
from datetime import date, timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.exceptions import InvalidBookingDatesException, RoomNotAvailableException
from backend.models import BookingStatus, Room, User
from backend.schemas.booking import BookingCreate
from backend.services.booking import BookingService


@pytest.mark.light
class TestBookingService:
    """Test booking service."""
    
    @pytest.mark.asyncio
    async def test_create_booking(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test creating a booking."""
        service = BookingService(test_db)
        
        booking_data = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today() + timedelta(days=1),
            check_out_date=date.today() + timedelta(days=3),
            num_adults=2,
            num_children=0,
        )
        
        booking = await service.create_booking(
            booking_data=booking_data,
            created_by_id=test_user.id,
        )
        
        assert booking is not None
        assert booking.guest_id == test_user.id
        assert booking.room_id == test_room.id
        assert booking.status == BookingStatus.PENDING
        assert booking.nights == 2
        assert booking.total_amount == test_room.base_price * 2
    
    @pytest.mark.asyncio
    async def test_create_booking_invalid_dates(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test creating a booking with invalid dates."""
        service = BookingService(test_db)
        
        booking_data = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today() + timedelta(days=3),
            check_out_date=date.today() + timedelta(days=1),  # Before check-in
            num_adults=2,
        )
        
        with pytest.raises(InvalidBookingDatesException):
            await service.create_booking(
                booking_data=booking_data,
                created_by_id=test_user.id,
            )
    
    @pytest.mark.asyncio
    async def test_create_booking_room_unavailable(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test creating a booking for unavailable room."""
        service = BookingService(test_db)
        
        # Create first booking
        booking_data = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today() + timedelta(days=1),
            check_out_date=date.today() + timedelta(days=3),
            num_adults=2,
        )
        
        booking1 = await service.create_booking(
            booking_data=booking_data,
            created_by_id=test_user.id,
        )
        
        # Update status to confirmed
        booking1.status = BookingStatus.CONFIRMED
        await test_db.commit()
        
        # Try to create overlapping booking
        booking_data2 = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today() + timedelta(days=2),
            check_out_date=date.today() + timedelta(days=4),
            num_adults=1,
        )
        
        with pytest.raises(RoomNotAvailableException):
            await service.create_booking(
                booking_data=booking_data2,
                created_by_id=test_user.id,
            )
    
    @pytest.mark.asyncio
    async def test_cancel_booking(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test cancelling a booking."""
        service = BookingService(test_db)
        
        # Create booking
        booking_data = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today() + timedelta(days=5),
            check_out_date=date.today() + timedelta(days=7),
            num_adults=2,
        )
        
        booking = await service.create_booking(
            booking_data=booking_data,
            created_by_id=test_user.id,
        )
        
        # Cancel booking
        cancelled_booking = await service.cancel_booking(
            booking_id=booking.id,
            reason="Test cancellation",
            cancelled_by_id=test_user.id,
        )
        
        assert cancelled_booking.status == BookingStatus.CANCELLED
        assert cancelled_booking.cancellation_reason == "Test cancellation"
        assert cancelled_booking.cancelled_at is not None
    
    @pytest.mark.asyncio
    async def test_check_in(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test checking in a guest."""
        service = BookingService(test_db)
        
        # Create booking for today
        booking_data = BookingCreate(
            guest_id=test_user.id,
            room_id=test_room.id,
            check_in_date=date.today(),
            check_out_date=date.today() + timedelta(days=2),
            num_adults=2,
        )
        
        booking = await service.create_booking(
            booking_data=booking_data,
            created_by_id=test_user.id,
        )
        
        # Confirm booking
        booking.status = BookingStatus.CONFIRMED
        await test_db.commit()
        
        # Check in
        checked_in_booking = await service.check_in(
            booking_id=booking.id,
            checked_in_by_id=test_user.id,
        )
        
        assert checked_in_booking.status == BookingStatus.CHECKED_IN
        assert checked_in_booking.actual_check_in is not None
    
    @pytest.mark.asyncio
    async def test_list_bookings(
        self,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
    ):
        """Test listing bookings."""
        service = BookingService(test_db)
        
        # Create multiple bookings
        for i in range(3):
            booking_data = BookingCreate(
                guest_id=test_user.id,
                room_id=test_room.id,
                check_in_date=date.today() + timedelta(days=i+10),
                check_out_date=date.today() + timedelta(days=i+12),
                num_adults=2,
            )
            
            await service.create_booking(
                booking_data=booking_data,
                created_by_id=test_user.id,
            )
        
        # List bookings
        bookings, total = await service.list_bookings(
            guest_id=test_user.id,
            limit=10,
        )
        
        assert len(bookings) == 3
        assert total == 3