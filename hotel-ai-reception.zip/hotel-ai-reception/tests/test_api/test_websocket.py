# path: tests/test_api/test_websocket.py
import json

import pytest
from fastapi.testclient import TestClient

from backend.core.security import create_access_token
from backend.main import app
from backend.models import User


@pytest.mark.light
class TestWebSocket:
    """Test WebSocket chat endpoint."""
    
    def test_websocket_without_auth(self):
        """Test WebSocket connection without authentication."""
        client = TestClient(app)
        
        with pytest.raises(Exception):
            with client.websocket_connect("/chat"):
                pass
    
    def test_websocket_with_invalid_token(self):
        """Test WebSocket connection with invalid token."""
        client = TestClient(app)
        
        with pytest.raises(Exception):
            with client.websocket_connect("/chat?token=invalid"):
                pass
    
    @pytest.mark.asyncio
    async def test_websocket_with_auth(self, test_user: User):
        """Test WebSocket connection with authentication."""
        client = TestClient(app)
        token = create_access_token({"sub": str(test_user.id), "email": test_user.email})
        
        with client.websocket_connect(f"/chat?token={token}") as websocket:
            # Should receive welcome message
            data = websocket.receive_json()
            assert data["type"] == "system"
            assert "Добро пожаловать" in data["content"]
            
            # Send text message
            websocket.send_json({
                "type": "text",
                "content": "Привет",
                "language": "ru"
            })
            
            # Should receive response
            response = websocket.receive_json()
            assert response["type"] == "text"
            assert "content" in response
    
    @pytest.mark.asyncio
    async def test_websocket_invalid_message(self, test_user: User):
        """Test WebSocket with invalid message format."""
        client = TestClient(app)
        token = create_access_token({"sub": str(test_user.id), "email": test_user.email})
        
        with client.websocket_connect(f"/chat?token={token}") as websocket:
            # Skip welcome message
            websocket.receive_json()
            
            # Send invalid message
            websocket.send_json({
                "invalid": "message"
            })
            
            # Should receive error
            response = websocket.receive_json()
            assert response["type"] == "error"
    
    @pytest.mark.asyncio
    async def test_websocket_typing_indicator(self, test_user: User):
        """Test WebSocket typing indicator."""
        client = TestClient(app)
        token = create_access_token({"sub": str(test_user.id), "email": test_user.email})
        
        with client.websocket_connect(f"/chat?token={token}") as websocket:
            # Skip welcome message
            websocket.receive_json()
            
            # Send typing indicator
            websocket.send_json({
                "type": "typing",
                "content": "",
                "language": "ru"
            })
            
            # Should not receive immediate response (typing is broadcast to others)
            import time
            time.sleep(0.1)  # Small delay to ensure no response