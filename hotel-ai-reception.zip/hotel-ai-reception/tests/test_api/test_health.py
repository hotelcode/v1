# path: tests/test_api/test_health.py
import pytest
from httpx import AsyncClient


@pytest.mark.light
class TestHealthEndpoints:
    """Test health check endpoints."""
    
    async def test_healthz(self, client: AsyncClient):
        """Test /healthz endpoint."""
        response = await client.get("/healthz")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "status" in data
        assert "service" in data
        assert "version" in data
        assert "environment" in data
        assert "checks" in data
        
        # Check required headers
        assert "X-Request-ID" in response.headers
        assert "X-Trace-ID" in response.headers
    
    async def test_livez(self, client: AsyncClient):
        """Test /livez endpoint."""
        response = await client.get("/livez")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["status"] == "alive"
    
    async def test_readyz(self, client: AsyncClient):
        """Test /readyz endpoint."""
        response = await client.get("/readyz")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "status" in data
        assert data["status"] in ["ready", "not_ready"]
    
    async def test_root(self, client: AsyncClient):
        """Test root endpoint."""
        response = await client.get("/")
        
        assert response.status_code == 200
        data = response.json()
        
        assert "name" in data
        assert "version" in data
        assert "environment" in data
        assert "status" in data
        assert data["status"] == "operational"