# path: tests/test_integration/test_e2e.py
import pytest
from datetime import date, timedelta
from decimal import Decimal
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models import User, Room, Booking, Payment, BookingStatus, PaymentStatus


@pytest.mark.heavy
class TestE2EScenarios:
    """End-to-end integration tests."""
    
    @pytest.mark.asyncio
    async def test_complete_booking_flow(
        self,
        client: AsyncClient,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
        auth_headers: dict,
    ):
        """Test complete booking flow from creation to payment."""
        # 1. Check room availability
        check_in = date.today() + timedelta(days=7)
        check_out = date.today() + timedelta(days=10)
        
        response = await client.get(
            "/api/v1/rooms/available",
            params={
                "check_in": check_in.isoformat(),
                "check_out": check_out.isoformat(),
            },
            headers=auth_headers,
        )
        assert response.status_code == 200
        available_rooms = response.json()
        assert len(available_rooms) > 0
        
        # 2. Create booking
        booking_data = {
            "guest_id": test_user.id,
            "room_id": test_room.id,
            "check_in_date": check_in.isoformat(),
            "check_out_date": check_out.isoformat(),
            "num_adults": 2,
            "num_children": 0,
            "special_requests": "Late check-in please",
        }
        
        response = await client.post(
            "/api/v1/bookings",
            json=booking_data,
            headers=auth_headers,
        )
        assert response.status_code == 201
        booking = response.json()
        booking_id = booking["id"]
        
        # 3. Get booking details
        response = await client.get(
            f"/api/v1/bookings/{booking_id}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        booking_details = response.json()
        assert booking_details["status"] == "pending"
        assert booking_details["total_amount"] == str(test_room.base_price * 3)
        
        # 4. Create payment
        payment_data = {
            "booking_id": booking_id,
            "amount": str(booking_details["total_amount"]),
            "currency": "KZT",
            "payment_method": "card",
            "card_last_four": "1234",
            "card_brand": "Visa",
        }
        
        response = await client.post(
            "/api/v1/payments",
            json=payment_data,
            headers=auth_headers,
        )
        assert response.status_code == 201
        payment = response.json()
        payment_id = payment["id"]
        
        # 5. Process payment
        response = await client.post(
            f"/api/v1/payments/{payment_id}/process",
            headers=auth_headers,
        )
        assert response.status_code == 200
        processed_payment = response.json()
        assert processed_payment["status"] == "completed"
        
        # 6. Verify booking is confirmed
        response = await client.get(
            f"/api/v1/bookings/{booking_id}",
            headers=auth_headers,
        )
        assert response.status_code == 200
        updated_booking = response.json()
        assert updated_booking["status"] == "confirmed"
        assert updated_booking["is_paid_in_full"] == True
    
    @pytest.mark.asyncio
    async def test_booking_cancellation_with_refund(
        self,
        client: AsyncClient,
        test_db: AsyncSession,
        test_user: User,
        test_room: Room,
        auth_headers: dict,
        manager_auth_headers: dict,
    ):
        """Test booking cancellation with refund flow."""
        # 1. Create and pay for booking
        check_in = date.today() + timedelta(days=10)
        check_out = date.today() + timedelta(days=12)
        
        # Create booking
        booking_data = {
            "guest_id": test_user.id,
            "room_id": test_room.id,
            "check_in_date": check_in.isoformat(),
            "check_out_date": check_out.isoformat(),
            "num_adults": 1,
            "num_children": 0,
        }
        
        response = await client.post(
            "/api/v1/bookings",
            json=booking_data,
            headers=auth_headers,
        )
        assert response.status_code == 201
        booking = response.json()
        booking_id = booking["id"]
        
        # Create and process payment
        payment_data = {
            "booking_id": booking_id,
            "amount": str(booking["total_amount"]),
            "currency": "KZT",
            "payment_method": "card",
            "card_last_four": "5678",
            "card_brand": "MasterCard",
        }
        
        response = await client.post(
            "/api/v1/payments",
            json=payment_data,
            headers=auth_headers,
        )
        payment = response.json()
        
        response = await client.post(
            f"/api/v1/payments/{payment['id']}/process",
            headers=auth_headers,
        )
        assert response.status_code == 200
        
        # 2. Cancel booking
        response = await client.post(
            f"/api/v1/bookings/{booking_id}/cancel",
            params={"reason": "Change of plans"},
            headers=auth_headers,
        )
        assert response.status_code == 200
        cancelled_booking = response.json()
        assert cancelled_booking["status"] == "cancelled"
        assert cancelled_booking["refund_amount"] is not None
        
        # 3. Process refund (as manager)
        refund_amount = cancelled_booking["refund_amount"]
        
        response = await client.post(
            f"/api/v1/payments/{payment['id']}/refund",
            json={
                "amount": refund_amount,
                "reason": "Booking cancelled by guest",
            },
            headers=manager_auth_headers,
        )
        assert response.status_code == 200
        refunded_payment = response.json()
        assert refunded_payment["status"] == "refunded"
        assert refunded_payment["refund_amount"] == refund_amount
    
    @pytest.mark.asyncio
    async def test_multiple_concurrent_bookings(
        self,
        client: AsyncClient,
        test_db: AsyncSession,
        auth_headers: dict,
    ):
        """Test handling multiple concurrent booking requests."""
        # Create multiple rooms
        rooms = []
        for i in range(5):
            room = Room(
                room_number=f"20{i}",
                floor=2,
                room_type="double",
                status="available",
                max_occupancy=2,
                single_beds=0,
                double_beds=1,
                base_price=30000,
                is_active=True,
            )
            test_db.add(room)
        
        await test_db.commit()
        
        # Get room IDs
        from sqlalchemy import select
        stmt = select(Room).where(Room.floor == 2)
        result = await test_db.execute(stmt)
        rooms = result.scalars().all()
        
        # Create concurrent booking requests
        import asyncio
        
        check_in = date.today() + timedelta(days=5)
        check_out = date.today() + timedelta(days=7)
        
        async def create_booking(room_id: int):
            booking_data = {
                "guest_id": 1,  # Assuming test_user.id = 1
                "room_id": room_id,
                "check_in_date": check_in.isoformat(),
                "check_out_date": check_out.isoformat(),
                "num_adults": 2,
                "num_children": 0,
            }
            
            return await client.post(
                "/api/v1/bookings",
                json=booking_data,
                headers=auth_headers,
            )
        
        # Send concurrent requests
        tasks = [create_booking(room.id) for room in rooms[:3]]
        responses = await asyncio.gather(*tasks)
        
        # All should succeed since different rooms
        for response in responses:
            assert response.status_code == 201
        
        # Try to book the same room concurrently
        tasks = [create_booking(rooms[4].id) for _ in range(3)]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Only one should succeed
        success_count = sum(1 for r in responses if not isinstance(r, Exception) and r.status_code == 201)
        assert success_count == 1