# path: tests/__init__.py
"""Tests for Hotel AI Reception."""