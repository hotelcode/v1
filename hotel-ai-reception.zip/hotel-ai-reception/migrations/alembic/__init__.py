# path: migrations/alembic/__init__.py
"""Alembic migrations for Hotel AI Reception."""